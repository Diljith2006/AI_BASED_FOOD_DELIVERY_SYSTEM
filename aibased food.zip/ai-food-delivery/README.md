# 🍛 Sizzle.AI — an AI food-delivery system built with Agile

A runnable prototype of a food-delivery platform whose five AI modules were built
sprint by sprint on a Scrum cadence, with every model scored against the naive
baseline it replaces.

Built as a **college mini/major project** deliverable: the code is the demo, the
numbers in `models/metrics.json` are the evidence, and `docs/AGILE_PLAN.md` is the
process documentation a reviewer will ask for.

---

## Quick start

```bash
pip install -r requirements.txt
python data/generate_data.py     # 1. build the synthetic order log (~11.5k orders)
python train.py                  # 2. train + evaluate every AI module (~25 s)
python app.py                    # 3. open http://localhost:8000
```

Everything runs **offline** — no API keys, no external services, no GPU.

---

## Currency

All money in the product is **Indian Rupees (₹, ISO code INR)** — no other currency
appears anywhere in the codebase. Formatting follows the Indian lakh/crore convention,
not western 3-digit grouping:

| Amount | Rendered |
|---|---|
| 45 | ₹45 |
| 1234.5 | ₹1,234.50 |
| 100000 | ₹1,00,000 |
| 1234567.5 | ₹12,34,567.50 |

`ai/currency.py` is the single source of truth (`inr()` for formatting, `inr_words()` for
bill-style amounts such as *"three hundred ninety-nine rupees and sixty-six paise only"*).
The server sends pre-formatted `*_inr` strings on every money field, the chatbot routes its
replies through the same formatter, and the UI carries a client-side twin of the same
algorithm. `GET /api/currency` reports the active currency at runtime.

## Dish photography

Menu items carry a photo (`static/img/<item_id>.jpg`, 640×349, ~45 KB each). The API
reports which photos exist on `/api/menu`; any dish still without one renders a designed
tile with its category icon instead of a broken-image icon. Run `python train.py` then
`python app.py`, and the header chip shows *photos 10/24*.

## Marketplace: restaurants & ratings

The app models a **15-restaurant marketplace in Coimbatore** with 89 dishes, not a single kitchen.
Each restaurant carries a name, locality, coordinates, cuisine, cost-for-two and a review count.

**Ranking uses a credibility rating, not the headline star.** A listing with 38 reviews at 4.9★
is not better than one with 1,310 reviews at 4.7★ — a naive average says it is. Every ranking
uses a Bayesian (shrunk) rating:

```
credibility = (v·R + m·C) / (v + m)      v = review count, R = star rating
                                         m = 50 pseudo-reviews, C = city mean (4.53★)
```

| Restaurant | Headline | Reviews | Credibility | Consequence |
|---|---|---|---|---|
| Sweet Karam Coffee | 4.8★ | 640 | **4.78** | ranks #1 |
| Chettinad Spice House | 4.7★ | 1,310 | **4.69** | proven, stable |
| Coastal Catch (new) | 4.9★ | 38 | **4.69** | tied — but only *after* 38 reviews |
| Bao & Beyond (new) | 4.8★ | 22 | **4.62** | pulled toward the mean |

**Discovery is a first-class feature, not a side effect.** Three surfaces exist because pure
exploitation can never surface a new kitchen:

1. *Exploration slot* — one recommendation per session is reserved for a restaurant the diner
   has never ordered from.
2. *New on Sizzle.AI* — newly onboarded listings, ranked by credibility, with an explicit
   "rating not yet proven" label.
3. *Restaurant tabs* — Best match / Top rated / New / Fastest, where "New" automatically
   excludes places the diner already uses.

The recommender also refuses to let novelty hijack the default ranking: an early version gave
new listings a large boost and they swamped Best match. The novelty weight is now 0.06, and
discovery gets its own budget instead.

### Carts that span restaurants

One rider cannot collect two kitchens for one delivery fee, so a multi-restaurant cart is
detected, priced (+₹15 per extra pickup), and labelled — with the rider paid extra for the
second stop. A real platform would split the order; the app says so on screen rather than
silently inflating the distance.

## What each sprint produced

| Sprint | Goal | Module | Headline evidence (out-of-fold / held-out) |
|---|---|---|---|
| 0 | Inception, backlog, architecture | `data/generate_data.py`, menu | 11,514 orders, 18,177 line items, 24 dishes |
| 1 | "Recommend me something" | `ai/recommender.py` | hybrid content + item-item CF + prior, filters as hard constraints, reasons attached |
| 2 | "When will it arrive?" | `ai/eta.py` | MAE **1.84 min**, R² 0.943 — vs 7.56 min for a fixed "always 27 min" rule |
| 3 | "Let me just type it" | `ai/chatbot.py` | 15 intents, **100%** intent / **89%** slot accuracy on a 12-case smoke set |
| 4 | "Why did the price change?" + kitchen planning | `ai/pricing.py`, `ai/forecast.py` | forecast MAE **19.6%** better than same-hour-last-week; price panel reconciles to the fee in every regime |
| 5 | "Where is my rider?" and hardening | `ai/logistics.py`, `app.py`, UX | constrained dispatch with capacity/perishability hard rejects; full pipeline demo in the browser |
| 6 | Multi-restaurant marketplace | `data/build_menu.py`, `ai/recommender.py`, `ai/geo.py` | 15 kitchens, credibility-rated ranking, exploration slot + "new & noteworthy"; multi-pickup cart pricing |

---

## The five AI modules (and the honest caveats)

1. **Hybrid recommender** — content-based cosine similarity (fixes cold start) blended
   0.45/0.35/0.20 with item-item collaborative filtering over real co-purchase baskets
   and a popularity/quality prior. Veg-only, spice ceiling and budget are applied as
   **hard filters before scoring**, so the model never ranks food a diner cannot eat.
   Every recommendation carries the reason it was chosen.

2. **ETA prediction** — Gradient Boosting with two extra quantile heads (p10/p90),
   scored with 5-fold cross-validation against both a Ridge linear model and a fixed-mean
   rule. Predictions come with a per-feature contribution breakdown from a linear
   surrogate, so the number is explainable in a viva.

3. **Ordering chatbot** — TF-IDF (1–2 grams) + logistic regression over 15 intents,
   plus rule-based slot filling for cuisine, veg flag, spice level, budget, quantity and
   dish name. Deliberately classical: it runs offline, and **every** decision is
   inspectable. Returns an intent confidence *and* the runner-up so mistakes are visible.

4. **Demand-aware pricing** — additive surge formula, hard-capped at 1.35×, with a
   rider-pay floor of 80% of the delivery fee. The explanation panel **reconciles exactly
   to the delivery fee** in every regime (including when the cap or floor binds) — checked
   in code, reported as `explanation_adds_up`.

5. **Demand forecast + dispatcher** — Ridge regression on hour/day-of-week dummies with a
   14-day item-mix layer behind it, backtested against a seasonal-naive baseline; and a
   constrained greedy rider assignment (capacity, distance, vehicle and perishability hard
   rejects) with a live ETA band.

### Being honest about the limits

- The dataset is **synthetic**, generated by `data/generate_data.py` with a known
  ground-truth process. It is realistic in shape but it is not a real order log, so the
  metrics prove the *pipeline* works, not that the model will hit 1.84 min MAE in
  production. Say this before a reviewer asks.
- The chatbot scores 100% on a 12-case smoke set. That set is small and curated; the
  honest next step (listed in the backlog) is 50+ utterances with a confusion matrix.
- Weather today comes from a manual scenario control, not a live API.
- The server is Flask's development server — fine for a demo, not for deployment.

---

## Project structure

```
ai-food-delivery/
├── app.py                    Flask API + UI (wires all five modules)
├── train.py                  one command: train, evaluate, write metrics.json
├── requirements.txt
├── ai/
│   ├── recommender.py        Sprint 1 — hybrid recommender
│   ├── eta.py                Sprint 2 — ETA model + explanation
│   ├── chatbot.py            Sprint 3 — intent classifier + dialogue manager
│   ├── currency.py           INR formatting: lakh/crore grouping + amount in words
│   ├── geo.py                Coimbatore localities + road distance (one source of truth)
│   ├── pricing.py            Sprint 4 — transparent surge pricing
│   ├── forecast.py           Sprint 4 — demand forecast + kitchen prep list
│   └── logistics.py          Sprint 5 — dispatch + tracking simulation
├── data/
│   ├── generate_data.py      synthetic order-stream generator (seed 42)
│   ├── build_menu.py         generates menu.json (15 restaurants, 89 dishes) + validates it
│   ├── menu.json             generated marketplace: restaurants, ratings, localities
│   ├── orders.csv            generated
│   ├── order_lines.csv       generated
│   ├── customers.csv         generated
│   └── riders.json           generated
├── models/
│   ├── eta_model.pkl         generated by train.py
│   └── metrics.json          generated by train.py (the evidence pack)
├── templates/index.html      single-page UI (3 tabs + chat drawer)
├── tests/test_guards.py      38 regression guards (wrong-answer bugs, not crashes)
└── docs/AGILE_PLAN.md        vision, personas, backlog, sprints, DoD, risks, retros
```

---

## API surface

| Endpoint | Method | What it shows |
|---|---|---|
| `/api/menu` | GET | marketplace: restaurants, menu **with photos + rupee strings**, photo coverage, currency |
| `/api/restaurants` | POST/GET | restaurant ranking (best match / top rated / new / fastest / cheapest) + new & noteworthy |
| `/api/currency` | GET | active currency (INR), grouping rule, worked examples |
| `/api/recommend` | POST | hybrid recommendations with score breakdown + reasons |
| `/api/eta` | POST | ETA with p10–p90 band, confidence, per-feature contributions |
| `/api/price` | POST | itemised quote, surge components, rider pay, 4 counterfactuals |
| `/api/chat` | POST | reply + intent + confidence + runner-up + slots + cart actions |
| `/api/forecast` | GET | 24-hour forecast, kitchen prep list, backtest metrics |
| `/api/dispatch` | POST | rider assignment, ranked candidates, policy rejections, tracking |
| `/api/order` | POST | whole pipeline in one call — what the checkout button hits |
| `/api/context` | GET/POST | read or move the scenario clock (hour / traffic / weather) |
| `/api/metrics` | GET | the evaluation numbers rendered in the Ops tab |

---

## Demo script (5 minutes, in this order)

1. **Order tab** → press *Re-rank with my filters* after setting **veg only + ₹250** —
   the picks change and each states *why*. Note that harder filters can never surface
   a non-veg dish.
2. **Add** the biryani + a coffee, hit **Place order**.
3. **Track tab** → ETA with its band, the per-feature "why this ETA" table, the rider
   card with the losers it beat, itemised pricing, and the counterfactual table.
4. **Scenario clock** → drag to 15:00 (off-peak) → everything requotes live: surge falls to
   the 0.90× floor, the ETA shortens, a different rider wins. Then set **rain at 8pm** —
   the cap binds, the customer's fee freezes, but the rider's earnings still rise.
5. **Forecast & Models tab** → tomorrow's curve, the kitchen prep list, then the
   scoreboards: every AI claim next to the baseline it must beat.
6. **SizzleBot** (💬 bottom-right) → `recommend something spicy veg under 250`,
   then `add two chicken 65` — the cart updates and the bot shows its intent confidence.

## Things to say if a reviewer pushes

- *"Why not a transformer / LLM for the chatbot?"* → offline, free, deterministic, and
  fully explainable; the NLU scoreboard is in the Ops tab. Swapping in an LLM is a
  backlog item, not a redesign.
- *"Is dynamic pricing fair?"* → capped at 1.35×, every rupee itemised, rider pay floored
  at 80% of the fee, and the panel is verified to reconcile.
- *"How do you know the models work?"* → every module is scored against a naive baseline
  on held-out data, not against a fixed mean, and the numbers regenerate with one command.
- *"Why not just sort by star rating?"* → because a 4.9★ from 22 reviews would beat a proven
  4.7★ from 1,310, which is exactly how marketplaces get gamed. Ranking uses the shrunk
  rating; the raw star is still displayed.
- *"How do new restaurants ever get discovered?"* → a reserved exploration slot, a New tab that
  excludes places you already use, and a "new & noteworthy" row — with the honest caveat that
  their ratings aren't proven yet.
- *"What went wrong?"* → see the retro notes in `docs/AGILE_PLAN.md`: the hour-encoding
  mistake that made the forecast lose to the naive baseline, the negation bug that flipped
  "nothing non veg" into a non-veg order, and the new-restaurant boost that hijacked the
  main ranking.
