"""
app.py — Sizzle.AI server: REST API + UI
========================================
Wires all five AI modules (recommender, ETA, chatbot, forecaster, pricing +
dispatch) behind one HTTP surface so the whole product can be demonstrated in
a browser, which is exactly what a sprint review needs.

Run:  python train.py   (once, to fit the models)
      python app.py     ->  http://localhost:8000
"""
from __future__ import annotations

import json, os, random, time
import numpy as np
from flask import Flask, jsonify, render_template, request

from ai.eta import ETAPredictor
from ai.recommender import HybridRecommender
from ai.chatbot import FoodChatbot
from ai.forecast import DemandForecaster
from ai.pricing import price_order, counterfactuals as price_counterfactuals
from ai.logistics import DispatchEngine, haversine_km
from ai.currency import currency_meta, inr, inr_words
from ai.geo import road_km

ROOT = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(ROOT, "data")
MODELS = os.path.join(ROOT, "models")
IMG_DIR = os.path.join(ROOT, "static", "img")

app = Flask(__name__)
app.config["JSON_SORT_KEYS"] = False

with open(os.path.join(DATA, "menu.json"), encoding="utf-8") as f:
    MENU_FILE = json.load(f)
MENU = MENU_FILE["items"]
RESTAURANTS = MENU_FILE["restaurants"]
BY_ID = {i["id"]: i for i in MENU}
BY_REST = {r["id"]: r for r in RESTAURANTS}

# ---- dish photography ------------------------------------------------
# Photos live as static/img/<item_id>.jpg.  We report which ones exist so the UI
# can fall back to a designed tile instead of flashing a broken-image icon.
# Missing photos are a *content* gap, not a code failure — the app must look
# deliberate either way.
IMAGE_FALLBACK_ICON = {
    "Breakfast": "🫓", "Main": "🍛", "Starter": "🥟", "Bread": "🫓",
    "Chinese": "🍜", "Fast Food": "🍔", "Dessert": "🍮", "Beverage": "🥤",
}


def _image_state(item: dict) -> dict:
    path = os.path.join(IMG_DIR, f"{item['id']}.jpg")
    return {
        "url": f"/static/img/{item['id']}.jpg",
        "available": os.path.exists(path),
        "fallback_icon": IMAGE_FALLBACK_ICON.get(item["category"], "🍽️"),
    }


def restaurant_for(rid: str, customer: dict | None = None) -> dict:
    """Restaurant record + the distance to THIS diner (not a city-centre hint)."""
    r = BY_REST[rid]
    c = customer or CUSTOMER_PROFILE
    dist = round(road_km((c["lat"], c["lng"]), (r["lat"], r["lng"])), 2) if c else None
    return {
        **r,
        "distance_km": dist,
        "eta_hint_min": round(r["prep_speed"] * 18 + (dist or r["distance_hint_km"]) * 2.6 + 8, 1),
        "credibility_rating": round(recommender.shrunk_rating(rid), 3),
        "tried_before": rid in set(c.get("restaurants_tried") or []) if c else None,
    }


def decorate(item: dict) -> dict:
    """Attach presentation metadata (photo, restaurant, formatted rupee strings)
    to an item without mutating the model layer's copy of the menu."""
    return {
        **item,
        "price_inr": inr(item["price"]),
        "price_words": inr_words(item["price"]),
        "image": _image_state(item),
        "restaurant": restaurant_for(item["restaurant_id"]),
    }

# ---- module singletons: loaded once at boot, then answered from memory ----
recommender = HybridRecommender()
chatbot = FoodChatbot()
forecaster = DemandForecaster()
dispatch_engine = DispatchEngine()
eta_model = ETAPredictor()
eta_loaded = False
if os.path.exists(os.path.join(MODELS, "eta_model.pkl")):
    try:
        eta_model.load()
        eta_loaded = True
    except Exception as e:                                   # pragma: no cover
        print(f"[warn] could not load ETA model ({e}); run train.py")

FORECAST_CACHE: dict = {}


def get_forecast(day_offset: int = 1) -> dict:
    if day_offset not in FORECAST_CACHE:
        FORECAST_CACHE[day_offset] = forecaster.next_day(day_offset)
    return FORECAST_CACHE[day_offset]


# --------------------------------------------------------------- simulation
CUSTOMER_PROFILE = {                 # demo diner (a sprint-review persona)
    "name": "Aarav",
    "orders_placed": 14,
    "cuisines": ["South Indian", "Arabian"],
    "veg_only": False,
    "max_spice": 3,
    "lat": 11.0280, "lng": 76.9630,   # Peelamedu-ish drop point
    "locality": "Peelamedu",
    # kitchens this diner has already ordered from — drives "new to you" suggestions
    "restaurants_tried": ["R01", "R04", "R06", "R10", "R15"],
}
CONTEXT = {"hour": 20, "day_of_week": 2, "traffic_level": 3, "weather": 0}


def _live_context() -> dict:
    """Serve the demo clock; real deployment would read datetime.now() + weather API."""
    now = time.localtime()
    demand = forecaster.demand_index(CONTEXT["hour"], day_offset=1)
    return {
        "hour": CONTEXT["hour"],
        "day_of_week": CONTEXT["day_of_week"],
        "traffic_level": CONTEXT["traffic_level"],
        "weather": CONTEXT["weather"],
        "weather_label": {0: "clear", 1: "cloudy", 2: "rain"}[CONTEXT["weather"]],
        "demand_index": demand,
        "riders_free": max(1, int(round(6 - 4 * (demand - 1)))),
        "note": f"scenario clock set to {CONTEXT['hour']:02d}:00 "
                f"(day {CONTEXT['day_of_week']}) — change it in the Scenario card",
    }


# ------------------------------------------------------------------ helpers
def _cart_totals(cart: list[dict]) -> dict:
    """Prices the cart and works out how many RESTAURANTS it spans.

    A marketplace cart can contain items from several kitchens. That is a real
    operational constraint, so it is computed here and used by pricing and the UI
    rather than discovered at delivery time.
    """
    items, subtotal, prep_times, units = [], 0.0, [], 0
    restaurants: dict[str, list[str]] = {}
    for line in cart or []:
        it = BY_ID.get(line.get("item_id"))
        if not it:
            continue
        qty = int(line.get("qty", 1))
        rid = it["restaurant_id"]
        restaurants.setdefault(rid, []).append(it["name"])
        items.append({"item_id": it["id"], "name": it["name"], "qty": qty,
                      "price": it["price"], "line_total": it["price"] * qty,
                      "price_inr": inr(it["price"]), "line_total_inr": inr(it["price"] * qty),
                      "veg": it["veg"], "spice": it["spice"],
                      "restaurant_id": rid, "restaurant_name": it["restaurant_name"],
                      "image": _image_state(it)})
        subtotal += it["price"] * qty
        # a restaurant's prep_speed scales how fast its kitchen turns orders around
        speed = BY_REST[rid]["prep_speed"]
        prep_times.append((it["prep_time_min"] + 2.0 * max(0, qty - 1)) * speed)
        units += qty
    primary = max(restaurants, key=lambda r: len(restaurants[r])) if restaurants else None
    return {"items": items, "subtotal": round(subtotal, 2), "units": units,
            "max_prep_time": max(prep_times) if prep_times else 0.0,
            "is_veg_only": all(i["veg"] for i in items) if items else True,
            "restaurant_ids": sorted(restaurants),
            "restaurants": [{"id": rid, "name": BY_REST[rid]["name"], "items": names}
                            for rid, names in restaurants.items()],
            "primary_restaurant_id": primary,
            "extra_pickups": max(0, len(restaurants) - 1),
            "spans_multiple_restaurants": len(restaurants) > 1}


def _context_for_eta(ctx: dict, totals: dict, customer_lat: float, customer_lng: float) -> dict:
    """ETA features. The distance that matters is customer -> the kitchen that is
    actually cooking this order, which is why the cart's primary restaurant is
    used rather than the city centre."""
    rid = totals.get("primary_restaurant_id")
    if rid:
        rest = BY_REST[rid]
        dist = road_km((customer_lat, customer_lng), (rest["lat"], rest["lng"]))
    else:
        dist = road_km((11.0168, 76.9558), (customer_lat, customer_lng))
    return {
        "distance_km": round(dist, 2),
        "restaurant_id": rid,
        "restaurant_name": BY_REST[rid]["name"] if rid else None,
        "prep_time_min": totals["max_prep_time"] or 12.0,
        "n_units": max(1, totals["units"]),
        "traffic_level": ctx["traffic_level"],
        "weather": ctx["weather"],
        "riders_free": ctx["riders_free"],
        "hour": ctx["hour"],
        "day_of_week": ctx["day_of_week"],
        "is_weekend": int(ctx["day_of_week"] >= 5),
    }


# =============================== API ======================================
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/menu")
def api_menu():
    with_photos = [i for i in MENU if _image_state(i)["available"]]
    return jsonify({
        "marketplace": MENU_FILE["marketplace"],
        "restaurants": [restaurant_for(r["id"]) for r in RESTAURANTS],
        "currency": currency_meta(),
        "items": [decorate(i) for i in MENU],
        "photos": {"with_photo": len(with_photos), "total": len(MENU),
                   "pending_item_ids": [i["id"] for i in MENU if not _image_state(i)["available"]]},
        "cuisines": sorted({i["cuisine"] for i in MENU}),
        "categories": sorted({i["category"] for i in MENU}),
        "localities": sorted({r["locality"] for r in RESTAURANTS}),
        "customer": CUSTOMER_PROFILE,
        "eta_model_ready": eta_loaded,
        "modules": {
            "recommender": "hybrid content + item-item collaborative filtering",
            "eta": "GradientBoosting, 5-fold CV, p10-p90 quantile band",
            "chatbot": f"TF-IDF + LogisticRegression over {len(chatbot.intents)} intents",
            "forecast": "Ridge with hour/day dummies, backtested vs seasonal-naive",
            "pricing": "bounded surge with rider-pay floor",
            "dispatch": "constrained greedy assignment",
            "restaurant_ranking": "Bayesian credibility rating (shrinkage toward the city mean)",
        },
    })


@app.route("/api/recommend", methods=["POST"])
def api_recommend():
    body = request.get_json(force=True, silent=True) or {}
    prefs = body.get("prefs") or {}
    tried = body.get("tried_restaurants", CUSTOMER_PROFILE.get("restaurants_tried"))
    res = recommender.recommend(prefs=prefs, cart_ids=body.get("cart_ids"),
                                n=int(body.get("n", 6)), tried_restaurants=tried)
    # the recommender owns its own menu copy, so presentation metadata is merged
    # here rather than duplicated inside the model layer
    for rec in res["recommendations"]:
        rec["item"] = decorate(rec["item"])
        rec["restaurant"] = restaurant_for(rec["item"]["restaurant_id"])
    if res.get("exploration_slot"):
        res["exploration_slot"]["item"] = decorate(res["exploration_slot"]["item"])
    res["currency"] = currency_meta()
    return jsonify(res)


@app.route("/api/restaurants", methods=["POST", "GET"])
def api_restaurants():
    """Restaurant-level suggestions: best match, top rated, new, fastest, cheapest."""
    body = request.get_json(force=True, silent=True) or {}
    sort = (body.get("sort") or request.args.get("sort") or "best_match")
    tried = body.get("tried_restaurants", CUSTOMER_PROFILE.get("restaurants_tried"))
    prefs = body.get("prefs") or {}
    res = recommender.discover_restaurants(prefs=prefs, tried_restaurants=tried,
                                           sort=sort, n=int(body.get("n", 8)),
                                           exclude_tried=body.get("exclude_tried"))
    for bucket in ("restaurants", "new_and_noteworthy"):
        for row in res.get(bucket, []):
            row["restaurant"] = restaurant_for(row["restaurant"]["id"])
    return jsonify(res)


@app.route("/api/currency")
def api_currency():
    return jsonify(currency_meta())


@app.route("/api/context", methods=["POST"])
def api_context_set():
    """Scenario control: lets a reviewer move the clock/weather and watch every
    AI module react.  This is the 'what-if' harness used in the sprint demo."""
    body = request.get_json(force=True, silent=True) or {}
    for k in ("hour", "day_of_week", "traffic_level", "weather"):
        if k in body:
            CONTEXT[k] = int(body[k])
    CONTEXT["hour"] = int(min(23, max(0, CONTEXT["hour"])))
    CONTEXT["traffic_level"] = int(min(3, max(1, CONTEXT["traffic_level"])))
    CONTEXT["weather"] = int(min(2, max(0, CONTEXT["weather"])))
    CONTEXT["day_of_week"] = int(min(6, max(0, CONTEXT["day_of_week"])))
    FORECAST_CACHE.clear()
    return jsonify(_live_context())


@app.route("/api/context")
def api_context():
    ctx = _live_context()
    fc = get_forecast(1)
    local_peak = max(fc["hourly"], key=lambda d: d["orders"])
    ctx["tomorrow"] = {"date": fc["target_date"], "weekday": fc["weekday"],
                       "total_orders": fc["total_orders"],
                       "peak_hour": local_peak["hour"], "peak_orders": local_peak["orders"]}
    return jsonify(ctx)


@app.route("/api/eta", methods=["POST"])
def api_eta():
    if not eta_loaded:
        return jsonify({"error": "ETA model not trained. Run: python train.py"}), 503
    body = request.get_json(force=True, silent=True) or {}
    ctx = _live_context()
    ctx.update({k: v for k, v in (body.get("context") or {}).items()})
    totals = _cart_totals(body.get("cart") or [])
    lat = float(body.get("lat", CUSTOMER_PROFILE["lat"]))
    lng = float(body.get("lng", CUSTOMER_PROFILE["lng"]))
    feats = _context_for_eta(ctx, totals, lat, lng)
    pred = eta_model.predict(feats)
    band_width = pred["eta_range"][1] - pred["eta_range"][0]
    label = "high" if band_width < 10 else ("medium" if band_width < 18 else "low")
    return jsonify({"prediction": pred, "confidence": label, "features": feats,
                    "cart_summary": totals, "context": ctx})


@app.route("/api/price", methods=["POST"])
def api_price():
    body = request.get_json(force=True, silent=True) or {}
    ctx = _live_context()
    totals = _cart_totals(body.get("cart") or [])
    lat = float(body.get("lat", CUSTOMER_PROFILE["lat"]))
    lng = float(body.get("lng", CUSTOMER_PROFILE["lng"]))
    feats = _context_for_eta(ctx, totals, lat, lng)
    quote = price_order(subtotal=totals["subtotal"], distance_km=feats["distance_km"],
                        demand_index=ctx["demand_index"], traffic_level=ctx["traffic_level"],
                        weather=ctx["weather"],
                        customer_orders=int(body.get("customer_orders", CUSTOMER_PROFILE["orders_placed"])),
                        extra_pickups=totals["extra_pickups"])
    # counterfactual panel: the same cart across times of day so a reviewer can
    # see the fee respond to context (and stop responding once the cap binds)
    scenarios = [
        {"label": "Off-peak · 3pm, light, clear", "hour": 15, "traffic": 1, "weather": 0},
        {"label": "Evening peak · 8pm, heavy, clear", "hour": 20, "traffic": 3, "weather": 0},
        {"label": "Weekend peak · 1pm Sat, moderate", "hour": 13, "traffic": 2, "weather": 0},
        {"label": "Peak + rain · 8pm, heavy, rain", "hour": 20, "traffic": 3, "weather": 2},
    ]
    for s in scenarios:
        s["demand"] = forecaster.demand_index(s["hour"], day_offset=1)
        s["customer_orders"] = CUSTOMER_PROFILE["orders_placed"]
    cf = price_counterfactuals(totals["subtotal"], feats["distance_km"], scenarios)
    # attach the rupee rendering of every line so the invoice cannot disagree
    # with the raw numbers under it
    quote["breakdown_inr"] = {k: inr(v) for k, v in quote["breakdown"].items()}
    quote["total_in_words"] = inr_words(quote["breakdown"]["total"])
    quote["rider_earnings_inr"] = inr(quote["rider_earnings"])
    for f in quote["explanation"]:
        f["rupees_inr"] = inr(f["rupees"])
    for c in cf:
        c.update({"delivery_fee_inr": inr(c["delivery_fee"]), "total_inr": inr(c["total"]),
                  "rider_earnings_inr": inr(c["rider_earnings"])})
    return jsonify({"quote": quote, "distance_km": feats["distance_km"],
                    "restaurant": restaurant_for(totals["primary_restaurant_id"]) if totals["primary_restaurant_id"] else None,
                    "spans_multiple_restaurants": totals["spans_multiple_restaurants"],
                    "counterfactuals": cf, "context": ctx, "currency": currency_meta()})


@app.route("/api/chat", methods=["POST"])
def api_chat():
    body = request.get_json(force=True, silent=True) or {}
    res = chatbot.respond(body.get("message", ""), cart=body.get("cart"),
                          prefs=body.get("prefs"))
    return jsonify(res)


@app.route("/api/forecast")
def api_forecast():
    day_offset = int(request.args.get("day_offset", 1))
    fc = get_forecast(day_offset)
    # 14-day history for the chart, from the real order log
    hist = forecaster.orders.copy()
    daily = (hist.groupby(hist.timestamp.dt.date).size().rename("orders").reset_index()
             .rename(columns={"timestamp": "date"}).tail(14))
    daily["date"] = daily["date"].astype(str)
    return jsonify({**fc, "history_14d": daily.to_dict("records"),
                    "baseline_note": "backtested on the final 7 days vs same-hour-last-week"})


@app.route("/api/dispatch", methods=["POST"])
def api_dispatch():
    if not eta_loaded:
        return jsonify({"error": "Train the models first: python train.py"}), 503
    body = request.get_json(force=True, silent=True) or {}
    ctx = _live_context()
    ctx.update({k: v for k, v in (body.get("context") or {}).items()})
    totals = _cart_totals(body.get("cart") or [])
    lat = float(body.get("lat", CUSTOMER_PROFILE["lat"]))
    lng = float(body.get("lng", CUSTOMER_PROFILE["lng"]))
    feats = _context_for_eta(ctx, totals, lat, lng)

    # refresh rider positions so each demo run is a fresh scenario
    rng = random.Random(int(time.time()))
    for r in dispatch_engine.riders:
        r["lat"] = round(11.0168 + rng.gauss(0, 0.026), 5)
        r["lng"] = round(76.9558 + rng.gauss(0, 0.026), 5)
        r["active_orders"] = rng.choice([0, 0, 1, 1, 2, 2, 3])
    result = dispatch_engine.assign(lat, lng, prep_time_min=feats["prep_time_min"],
                                    traffic_level=ctx["traffic_level"], weather=ctx["weather"])
    eta = eta_model.predict(feats)
    tracking = dispatch_engine.simulate_tracking(
        result["assigned"], result["assigned"]["travel_min"],
        queue_min=feats["prep_time_min"] * 0.55, demand_index=ctx["demand_index"],
        target_eta_min=eta["eta_min"])     # timeline must reconcile to the model ETA
    tracking["traffic_level"] = ctx["traffic_level"]
    rider_geo = next((r for r in dispatch_engine.riders
                      if r["rider_id"] == result["assigned"]["rider_id"]), None)
    band = eta["eta_range"][1] - eta["eta_range"][0]
    eta_block = {"prediction": eta, "features": feats,
                 "confidence": "high" if band < 10 else ("medium" if band < 18 else "low")}
    pickup = restaurant_for(totals["primary_restaurant_id"]) if totals["primary_restaurant_id"] else None
    if totals["spans_multiple_restaurants"] and pickup:
        pickup = {**pickup,
                  "stops": [{"id": r["id"], "name": r["name"]} for r in totals["restaurants"]],
                  "note": f"{len(totals['restaurants'])} pickups on this run — a real platform would "
                          f"split this into separate orders"}
    return jsonify({"dispatch": result, "eta": eta_block, "tracking": tracking,
                    "pickup": pickup,
                    "customer": {"lat": lat, "lng": lng, "locality": CUSTOMER_PROFILE["locality"]},
                    "rider_geo": {"lat": rider_geo["lat"] if rider_geo else None,
                                  "lng": rider_geo["lng"] if rider_geo else None},
                    "context": ctx})


@app.route("/api/order", methods=["POST"])
def api_order():
    """Full pipeline: price -> predict ETA -> dispatch -> return an order object."""
    body = request.get_json(force=True, silent=True) or {}
    cart = body.get("cart") or []
    if not cart:
        return jsonify({"error": "Cart is empty — add something delicious first."}), 400
    price_resp = api_price().get_json()
    dispatch_resp = api_dispatch().get_json()
    oid = "O" + str(random.randint(10000, 99999))
    return jsonify({
        "order_id": oid,
        "status": "confirmed",
        "currency": currency_meta(),
        "pricing": price_resp["quote"],
        "counterfactuals": price_resp["counterfactuals"],
        "eta": dispatch_resp["eta"],
        "tracking": dispatch_resp["tracking"],
        "dispatch": dispatch_resp["dispatch"],
        "pickup": dispatch_resp.get("pickup"),
        "cart_summary": _cart_totals(cart),
        "context": _live_context(),
    })


@app.route("/api/metrics")
def api_metrics():
    path = os.path.join(MODELS, "metrics.json")
    if not os.path.exists(path):
        return jsonify({"error": "No metrics yet — run python train.py"}), 404
    with open(path, encoding="utf-8") as f:
        return jsonify(json.load(f))


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8000"))
    print(f"\n  Sizzle.AI running on http://0.0.0.0:{port}")
    print(f"  ETA model loaded: {eta_loaded}")
    app.run(host="0.0.0.0", port=port, debug=False, threaded=True)
