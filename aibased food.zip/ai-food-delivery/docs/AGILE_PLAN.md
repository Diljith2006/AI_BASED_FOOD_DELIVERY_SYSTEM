# Sizzle.AI — Agile Project Plan

**Project:** AI-based food delivery system
**Method:** Scrum, 6 sprints (Sprint 0–5), 1-week sprints
**Team:** 4 (2 developers, 1 ML/analytics owner, 1 product owner who also tests)
**Definition of "done" for the whole project:** a reviewer can open the app, place an order,
and see every AI claim traced to a number produced by `python train.py`.

---

## 1. Product vision

> For hungry people in Coimbatore who don't want to think about what to order, Sizzle.AI is a
> food-delivery app that recommends the right dish, tells the truth about when it will arrive,
> and explains every rupee it charges — unlike existing apps that hide the ETA and the surge
> behind a single number.

**Product goal:** a working end-to-end prototype where all five AI features are measured
against a naive baseline, not asserted.

**Out of scope (v1):** real payments, real restaurant integrations, live weather/GPS feeds,
production deployment, multi-city scaling.

---

## 2. Personas

| Persona | Cares about | Maps to AI module |
|---|---|---|
| **Aarav**, 26, working professional, orders 4×/week | "Just tell me what to eat, and be honest about the ETA" | Recommender, ETA, Chatbot |
| **Lakshmi**, kitchen manager | "Tell me how much to prep before the rush" | Demand forecast, prep list |
| **Suresh**, delivery partner | "Pay me fairly when it rains or the roads are jammed" | Pricing (rider floor), Dispatch |
| **Priya**, ops analyst | "Show me why the model said that" | Explanations, metrics tab |

---

## 3. Product backlog (MoSCoW)

Points are story points (Fibonacci). Priority: M = must, S = should, C = could.

| ID | User story | Pts | P | Sprint | Acceptance criteria (summary) |
|---|---|---|---|---|---|
| US-01 | As a diner, I want dish recommendations so I don't have to browse 24 items | 8 | M | 1 | Top-5 list changes with preferences; every item carries a human-readable reason |
| US-02 | As a diner, I want my dietary rules respected | 5 | M | 1 | Veg-only / spice / budget act as **hard** filters; no violating item is ever ranked |
| US-03 | As a reviewer, I want to see *why* a dish was recommended | 3 | M | 1 | Score breakdown (content / collaborative / prior) visible per item |
| US-04 | As a diner, I want a delivery ETA before I pay | 13 | M | 2 | ETA + 80% interval returned; out-of-fold MAE better than both baselines |
| US-05 | As a diner, I want to know why my ETA is long | 5 | S | 2 | Per-feature contribution table in minutes |
| US-06 | As a reviewer, I want the ETA model's error stated plainly | 3 | M | 2 | MAE/RMSE/R² vs Ridge and vs fixed-mean rule in `metrics.json` |
| US-07 | As a diner, I want to order by typing plain English | 13 | M | 3 | 15 intents; cart add/remove executed from chat; confidence shown |
| US-08 | As a diner, I want the bot to ask before guessing | 5 | S | 3 | Low confidence (<0.22) triggers a fallback, never a wrong add-to-cart |
| US-09 | As a diner, I want to see why the price changed | 8 | M | 4 | Every rupee itemised; panel reconciles exactly to the fee (incl. caps) |
| US-10 | As a kitchen manager, I want tomorrow's prep plan | 8 | M | 4 | Hourly forecast + per-dish unit list for the 3 peak hours |
| US-11 | As a delivery partner, I want fair pay in bad conditions | 8 | M | 4 | Rider pay ≥ 80% of delivery fee; rain bonus survives surge cap |
| US-12 | As a diner, I want to track my rider | 8 | M | 5 | Assignment + ranked alternatives + tracking timeline |
| US-13 | As an ops user, I want capacity and perishability respected | 5 | S | 5 | Riders over capacity / cycle on long runs are hard-rejected with a reason |
| US-14 | As a reviewer, I want to move the clock and watch AI react | 5 | C | 5 | Scenario control requotes price/ETA/dispatch live |
| US-15 | As a diner, I want off-peak to be cheaper | 3 | C | 4 | Off-peak floor gives a 10% discount; capped at 1.35× at peak |
| US-16 | (Backlog) Expand chatbot eval to 50+ utterances + confusion matrix | 5 | S | 6 | ≥95% intent accuracy reported per class |
| US-17 | (Backlog) Swap weather scenario for a live weather API | 5 | C | 6 | Rain flag fetched hourly; forecast multiplier driven by it |
| US-18 | A/B test recommender weights | 8 | C | 6 | (deferred) Weight variants compared on held-out click/order proxy |
| US-19 | As a diner, I want to see the restaurant I'm ordering from | 5 | M | 6 | Every dish card, cart line and order shows the kitchen; multi-restaurant carts are flagged |
| US-20 | As a diner, I want suggestions ranked by genuine quality | 8 | M | 6 | Ranking uses a shrunk (credibility) rating, not the raw star average; thin evidence is pulled toward the city mean |
| US-21 | As a diner, I want to discover restaurants I haven't tried | 8 | M | 6 | Exploration slot + "New on Sizzle" tab (excludes already-tried kitchens) + new & noteworthy row |
| US-22 | As a delivery partner, I want to be paid for a second pickup | 3 | S | 6 | ₹15 per extra restaurant, itemised and shown on screen, rider paid extra |

**Velocity:** 24 pts (S1) → 21 (S2) → 18 (S3) → 29 (S4) → 18 (S5) → 24 (S6). Average ≈ 22 pts/sprint.

---

## 4. Sprint plan

| Sprint | Goal (one sentence) | Backlog items | Delivered artifact | Demo shown |
|---|---|---|---|---|
| **0** | Get inception, data and architecture out of the way | env, menu, synthetic order log, architecture | `data/generate_data.py`, `menu.json`, 11.5k-order log | walking skeleton: menu served by Flask |
| **1** | Prove we can recommend well and respect constraints | US-01/02/03 | `ai/recommender.py` | filters change picks; reasons shown |
| **2** | Make the ETA honest and explainable | US-04/05/06 | `ai/eta.py` + `models/metrics.json` | ETA band, why-this-ETA table, scoreboard |
| **3** | Let people order in plain language | US-07/08 | `ai/chatbot.py` | chatbot performing a real add-to-cart |
| **4** | Money and kitchen: fair pricing + prep planning | US-09/10/11/15 | `ai/pricing.py`, `ai/forecast.py` | itemised fee, counterfactuals, prep list |
| **5** | Dispatch, tracking and demo hardening | US-12/13/14 | `ai/logistics.py`, `app.py`, UI | checkout → price → ETA → rider in one click |

### Sprint 0 — inception
Architecture chosen (Flask + scikit-learn, no external services) so the demo works on any
examiner's laptop with no API keys. Menu modelled on a real Coimbatore menu (Chettinad biryani,
Madurai parotta, Al Fahm, filter coffee) so the demo feels local rather than generic.

### Sprint 1 — recommender
Two failures found in review: (a) pure content-based recommending kept surfacing items the
diner had already ordered, (b) collaborative filtering alone broke for new users. Fix: blend
the three signals and pass the cart as context, so the CF term only activates when there *is*
a cart. **Retro action:** every recommendation must carry a reason, because a ranked list with
no explanation is unusable in a food app.

### Sprint 2 — ETA
First attempt encoded hour-of-day as sine/cosine, and the model was *worse* than a linear
baseline in some slices. Retro finding: the ETA responds to *sharp* structure (peak-hour
traffic, rain during the peaks), which sine waves cannot represent. Fix: one-hot hour + a
convex kitchen-queue penalty feature. Result: MAE fell to 1.84 min, R² 0.943, and the model
finally beat the linear baseline — which is the whole point of using a tree ensemble here.

### Sprint 3 — chatbot
Two bugs fixed during the sprint, both worth quoting in a viva:
1. **Wrong-dish risk:** "a spicy veg dinner under 250" fuzzy-matched *Veg Burger* because
   "veg" appeared in its name. Fix: only dish-specific tokens can trigger a match; generic
   craving words (`veg`, `spicy`, `dinner`, `cheap`) are on a stop-list.
2. **Polarity bug:** "nothing **non veg**" contains the substring "non veg", so a naive
   keyword scan flipped the diner to non-vegetarian. Fix: negations are stripped before the
   negative lexicon runs.
Also added a disambiguation rule: a *preference statement* ("I'm vegetarian" → `diet`) versus
a *craving request* ("I'm vegetarian, something spicy under 250" → `recommend` with
`veg_only` as a slot).

### Sprint 4 — pricing and forecasting
Pricing went through three revisions, each caught by a test rather than by opinion:
1. The surge formula saturated at the cap during any evening peak, so off-peak and peak fees
   barely differed → demand term moved to a log scale (peak now 1.32×, off-peak 0.90×).
2. Explanation rows did **not** sum to the delivery fee when the cap or floor bound → rupees
   are now attributed in two steps (proportional split + explicit policy adjustment) and the
   API reports `explanation_adds_up`. *If it doesn't reconcile, it isn't transparent.*
3. Rain raised the fee but not rider pay under the cap → rain bonus is funded outside the
   cap, so the rider earns more even when the customer's fee freezes.
Forecast: the first version used sin/cos hour encoding and **lost to the same-hour-last-week
baseline by 70%**. Fix: hour-of-day dummies + weekend×peak interactions → now 19.6% better
than the naive baseline on MAE and 24.0% WAPE in service windows.

### Sprint 6 — from one kitchen to a marketplace
Adding restaurants was not a data change; it invalidated assumptions elsewhere:

1. **Ratings had to stop being naive.** With 15 kitchens, the raw 4.9★ of a brand-new listing
   outranked every proven kitchen. Fix: a Bayesian shrunk rating `(v·R + 50·C)/(v + 50)` used by
   the recommender, the restaurant ranking, the chatbot *and* the "sort by rating" control, so
   the whole product agrees on one definition of "well rated".
2. **Discovery needed its own budget.** Reserving an exploration slot surfaces a new kitchen each
   session. A first attempt instead boosted new listings inside Best match — they swamped the
   ranking, which would mean pushing unproven kitchens at every diner. Novelty weight was cut to
   0.06 and new places got their own tab instead.
3. **A cart became a multi-restaurant problem.** One rider cannot collect two kitchens for one
   delivery fee, so carts are now grouped by kitchen, priced at +₹15 per extra pickup, itemised
   in the panel the tests already check, and the rider is paid more for the second stop.
4. **Distances became real.** Customer and restaurant coordinates come from one shared table of
   Coimbatore localities (`ai/geo.py`), so the ETA feature, the fee tier and the dispatch score
   all refer to the same distance instead of three random draws. Adding this immediately showed
   customers ordering 16 km across the city, which is why restaurant choice now decays with
   distance — and mean ETA fell from 48 to 36 minutes.

**Retro:** the marketplace change touched pricing, dispatch, forecasting, the chatbot and the UI.
Every one of the five bugs above was found by a check rather than by opinion — which is the
argument for building the guards before the feature.

### Sprint 5 — dispatch and hardening
Greedy assignment chosen over an ILP because with a few dozen riders the gap is negligible
and the response is instant — the trade-off is documented in `ai/logistics.py`. Hard rejects
(capacity, cycle on long runs, food going cold) are surfaced in the UI with reasons, because
"why wasn't I assigned?" is the first question an ops user asks.

---

## 5. Definition of Done (applies to every story)

1. Code runs from a clean checkout with `python train.py && python app.py`.
2. If the story contains a model claim, it has a **baseline** and a number in `metrics.json`.
3. The UI shows the output *and* the reason behind it.
4. Failure paths handled: empty cart, untrained model, low-confidence intent, cap-bound surge.
5. Retro note added describing what surprised us.

## 6. Ceremonies and working agreements

- **Sprint planning** (Mon, 45 min): pick stories, agree the demo scenario for Friday.
- **Daily stand-up** (15 min): yesterday / today / blockers.
- **Sprint review** (Fri, 30 min): run the demo script end to end on the real app; no slides.
- **Retro** (Fri, 20 min): one thing kept, one dropped, one tried — recorded per sprint above.
- **Working agreements:** models are only merged with a baseline comparison; no secrets or
  network calls in the demo path; every module has a single entry point that training and
  serving both call (kills train/serve skew).

---

## 7. Risk register

| # | Risk | Impact | Likelihood | Mitigation / status |
|---|---|---|---|---|
| R1 | Synthetic data makes metrics look better than reality | High | High | Stated plainly in README and the Ops tab; retraining on a real log is backlog US-17 |
| R2 | Model opacity (can't defend a number in viva) | High | Medium | Surrogate contributions for ETA; reasons for each recommendation; itemised pricing |
| R3 | Only 12 chatbot eval cases → inflated accuracy | Medium | High | Reported as a *smoke set*, not accuracy; US-16 expands it |
| R4 | Surge pricing perceived as exploitative | High | Medium | 1.35× hard cap, 0.90× floor, rider-pay floor of 80%, additive audited panel |
| R5 | Train/serve feature skew | Medium | Medium | One `build_features()` used by both training and the API |
| R6 | Demo fails live (env, ports, missing model) | Medium | Medium | Zero external dependencies; `/api/eta` returns a clear 503 with the fix command |
| R7 | Overfitting on 90 days of history | Medium | Medium | Linear/simple models by choice; 5-fold CV and held-out backtest; baselines mandatory |
| R8 | Rider starvation (few riders, many orders) | Medium | Medium | Load term in the scoring function + graceful degradation to least-loaded rider |

---

## 8. Traceability: story → module → evidence

| Story | Module | Where a reviewer can verify it |
|---|---|---|
| US-01/02/03 | `ai/recommender.py` | Order tab → "AI recommendations"; scores + reasons per card |
| US-04/05/06 | `ai/eta.py` | Track tab → ETA band + "Why this ETA?"; Ops tab → scoreboard |
| US-07/08 | `ai/chatbot.py` | 💬 drawer → intent, confidence, runner-up, slots shown under every reply |
| US-09/11/15 | `ai/pricing.py` | Track tab → itemised breakdown, rider floor note, counterfactual table |
| US-10 | `ai/forecast.py` | Ops tab → 24-hour curve, prep list, backtest note |
| US-12/13/14 | `ai/logistics.py`, `app.py` | Track tab → rider card, rejected riders, scenario clock |

---

## 9. Metrics that define project success

| Metric | Target | Achieved |
|---|---|---|
| ETA MAE (5-fold CV) | < 4 min | **1.85 min** |
| ETA model beats linear baseline | yes | 1.85 vs 2.16 min |
| Forecast beats seasonal-naive | ≥ 10% better MAE | **20.9%** |
| Rating ranking resists thin evidence | must hold | 4.9★/38 reviews ranks ≤ proven 4.7★/1,310 |
| New restaurants are discoverable | ≥ 1 dedicated surface | exploration slot + New tab + new & noteworthy row |
| Chatbot intent accuracy (smoke set) | ≥ 90% | **100%** (12 cases — expand before claiming) |
| Slot-fill accuracy on expected slots | ≥ 85% | **89%** |
| Price explanation reconciles to fee | 100% of regimes | 100% (checked in code) |
| End-to-end demo without manual steps | yes | ✅ one command, no keys |

---

## 10. What we would do in Sprint 6 (and after)

1. **US-16** — grow the chatbot evaluation set to 50+ utterances and publish a confusion
   matrix; report per-class precision/recall instead of one aggregate.
2. **US-17** — live weather + GPS: turn the scenario clock into a real feed and add a
   forecast-driven rain multiplier.
3. ~~Regression guards for the Sprint 3/4 bugs~~ — **done ahead of schedule**:
   `tests/test_guards.py` now asserts 38 invariants (price panel reconciles in all six surge
   regimes, no non-veg item under `veg_only`, negated-meat polarity, no phantom dish matches,
   tracking timeline equals the ETA model's own number, models beat their baselines). Run it
   with `python tests/test_guards.py`; it exits non-zero on failure so it can gate a build.
4. Move from Flask's dev server to a WSGI server and containerise for a one-line deploy.
5. Real-data pilot: log ~2 weeks of genuine orders and re-run `train.py` to see how much of
   the synthetic performance survives contact with reality.
