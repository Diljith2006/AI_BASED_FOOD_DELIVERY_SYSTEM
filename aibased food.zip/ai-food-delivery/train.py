"""
train.py — one command to train + evaluate every AI module and write a report.
Usage:  python train.py
Artifacts:
  models/eta_model.pkl        trained ETA predictor (point + p10/p90 heads)
  models/metrics.json         all evaluation numbers (shown in the UI "Models" tab)
"""
import json, os, sys, time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pandas as pd

from ai.eta import ETAPredictor
from ai.forecast import DemandForecaster

ROOT = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(ROOT, "data")
MODELS = os.path.join(ROOT, "models")
os.makedirs(MODELS, exist_ok=True)

t0 = time.time()
report = {}

print("=" * 68)
print("Sizzle.AI — training run")
print("=" * 68)

# ---------------------------------------------------------------- ETA model
print("\n[1/2] ETA prediction — GradientBoosting + quantile heads")
orders = pd.read_csv(os.path.join(DATA, "orders.csv"), parse_dates=["timestamp"])
eta = ETAPredictor()
m = eta.train(orders)
report["eta"] = m
for name in ("ML_GradientBoosting", "baseline_Ridge", "baseline_fixed_mean_rule"):
    s = m[name]
    print(f"   {name:26} MAE {s['MAE']:5.2f} min | RMSE {s['RMSE']:5.2f} | R2 {s['R2']:6.3f}")
print(f"   rows={m['n_train']}  folds={m['cv_folds']}  "
      f"improvement vs fixed rule: "
      f"{(1 - m['ML_GradientBoosting']['MAE'] / m['baseline_fixed_mean_rule']['MAE']) * 100:.1f}%")
print("   top features:", ", ".join(list(m["feature_importance"])[:5]))

# ------------------------------------------------------------ demand forecast
print("\n[2/2] Demand forecast — Ridge on calendar features")
fc = DemandForecaster()
fm = fc.train(holdout_days=7)
report["forecast"] = {k: v for k, v in fm.items() if k != "hourly"}
print(f"   holdout {fm['holdout_days']} days / {fm['holdout_points']} hourly buckets")
print(f"   ML    MAE {fm['ML_Ridge']['MAE_orders_per_hour']:5.2f} orders/hr | "
      f"WAPE(all h) {fm['ML_Ridge']['WAPE_pct_all_hours']}% | "
      f"WAPE(service windows) {fm['ML_Ridge']['WAPE_pct_service_windows']}%")
print(f"   naive MAE {fm['baseline_seasonal_naive']['MAE_orders_per_hour']:5.2f} orders/hr | "
      f"WAPE(all h) {fm['baseline_seasonal_naive']['WAPE_pct_all_hours']}% | "
      f"WAPE(service windows) {fm['baseline_seasonal_naive']['WAPE_pct_service_windows']}%")
print(f"   improvement vs seasonal-naive: {fm['MAE_improvement_vs_naive_pct']}%")
nxt = fc.next_day(1)
print(f"   tomorrow ({nxt['target_date']}, {nxt['weekday']}): {nxt['total_orders']} orders, "
      f"peak {nxt['peak_hour']:02d}:00 ({nxt['peak_orders']}/hr)")

# --------------------------------------------------- recommender + chatbot QC
print("\n[3/4] Recommender + chatbot quality checks")
from ai.recommender import HybridRecommender
from ai.chatbot import FoodChatbot

rec = HybridRecommender()
demo = rec.recommend({"cuisines": ["South Indian"], "veg_only": True, "max_price": 250, "max_spice": 2}, n=3)
report["recommender"] = {
    "model": demo["model"], "weights": demo["weights"],
    "cf_baskets_used": demo["cf_baskets_seen"],
    "sample_top3": [{"name": r["item"]["name"], "score": r["score"], "reason": r["reason"]}
                    for r in demo["recommendations"]],
}
for r in demo["recommendations"]:
    print(f"   {r['item']['name']:34} {r['score']:.3f}  — {r['reason']}")

bot = FoodChatbot()
# Each case: utterance, expected intent, expected slot keys that MUST be filled.
# Scoring slots only where the utterance actually carries one is the fair test
# (a plain "how long will delivery take" has no slot to fill).
EVAL = [
    ("I want a spicy veg dinner under 250", "recommend", ["max_spice", "vegetarian_flag", "max_price"]),
    ("recommend something under 200", "recommend", ["max_price"]),
    ("add two chicken 65", "add_to_cart", ["item_id", "qty"]),
    ("do you have shawarma", "search", ["item_id"]),
    ("how long will delivery take", "eta", []),
    ("why is the price so high today", "price", []),
    ("clear my cart", "remove_from_cart", []),
    ("i am vegetarian", "diet", ["vegetarian_flag"]),
    ("nothing non veg please", "diet", ["vegetarian_flag"]),
    ("where is my order", "track", []),
    ("show me the menu", "menu", []),
    ("thanks buddy", "thanks", []),
]
correct, slot_hits, slot_checks = 0, 0, 0
rows = []
for text, want, want_slots in EVAL:
    res = bot.respond(text)
    ok = res["intent"] == want
    correct += ok
    s = res["slots"]
    got = []
    for k in want_slots:
        slot_checks += 1
        hit = (bool(s.get("veg_only")) if k == "vegetarian_flag" else bool(s.get(k)))
        slot_hits += hit
        got.append(f"{k}={'OK' if hit else 'missing'}")
    rows.append({"utterance": text, "expected_intent": want, "predicted_intent": res["intent"],
                 "correct": bool(ok), "confidence": res["confidence"],
                 "expected_slots": want_slots, "slots": got,
                 "reply": res["reply"][:120]})
    print(f"   {'OK  ' if ok else 'MISS'} '{text[:36]:38}' -> {res['intent']:18} "
          f"({res['confidence']:.2f})  {'; '.join(got) if got else 'no slots expected'}")
report["chatbot"] = {
    "intent_accuracy_on_smoke_set": round(correct / len(EVAL), 3),
    "slot_fill_accuracy_on_expected_slots": round(slot_hits / max(1, slot_checks), 3),
    "trained_utterances": bot.n_train_utterances,
    "n_intents": len(bot.intents),
    "cases": rows,
    "note": "curated smoke set — expand to 50+ utterances and report a confusion matrix in the final report",
}
print(f"   intent accuracy {report['chatbot']['intent_accuracy_on_smoke_set']:.0%} | "
      f"slot-fill accuracy {report['chatbot']['slot_fill_accuracy_on_expected_slots']:.0%} "
      f"({slot_hits}/{slot_checks} expected slots)")

# ------------------------------------------------------------------ dispatch
print("\n[4/4] Dispatch — rider assignment sanity check")
from ai.logistics import DispatchEngine
eng = DispatchEngine()
d = eng.assign(11.0280, 76.9630, prep_time_min=16.0, traffic_level=3, weather=2)
print(f"   assigned {d['assigned']['name']} ({d['assigned']['distance_km']} km, "
      f"{d['assigned']['travel_min']} min ride, score {d['assigned']['score']})")
print(f"   rejected {len(d['hard_rejections'])} riders on policy grounds "
      f"(capacity / distance / vehicle type)")
report["dispatch"] = {"assigned": d["assigned"], "n_rejected": len(d["hard_rejections"]),
                      "policy": d["policy"]}

# ------------------------------------------------------------------- persist
report["generated_at"] = time.strftime("%Y-%m-%d %H:%M")
report["train_seconds"] = round(time.time() - t0, 1)
with open(os.path.join(MODELS, "metrics.json"), "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2, default=str)

print("\n" + "=" * 68)
print(f"Done in {report['train_seconds']}s. Metrics -> models/metrics.json")
print("Next:  python app.py   ->  http://localhost:8000")
print("=" * 68)
