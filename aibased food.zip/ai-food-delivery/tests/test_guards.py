"""
tests/test_guards.py — regression guards for the bugs found during the sprints.

Run:  python tests/test_guards.py       (no pytest needed)

These exist because every one of these failures was a *silent wrong answer*, not
a crash — the worst kind of bug in a food app. A model that quietly adds the
wrong dish, flips a vegetarian diner to non-veg, or prints a price breakdown that
doesn't add up would still "pass" a naive smoke test.
"""
import json, os, sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ai.chatbot import FoodChatbot
from ai.pricing import price_order
from ai.recommender import HybridRecommender
from ai.currency import inr, inr_words

PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  {'PASS' if cond else 'FAIL'}  {name}" + (f"   -> {detail}" if detail else ""))


print("\n[1] Pricing panel must reconcile to the delivery fee in EVERY regime")
regimes = [
    ("off-peak floor binds", 0.50, 1, 0),
    ("normal day",            1.60, 2, 0),
    ("peak, cap binds",       2.65, 3, 0),
    ("peak + rain, cap binds", 2.65, 3, 2),
    ("midnight",              0.40, 1, 0),
    ("rain only",             1.10, 1, 2),
]
for label, dem, tr, wx in regimes:
    q = price_order(260, 3.2, dem, tr, wx, customer_orders=14)
    rows = sum(f["rupees"] for f in q["explanation"])
    fee = q["breakdown"]["delivery_fee"]
    check(f"rows reconcile ({label})", abs(rows - fee) <= 0.05,
          f"rows {rows:.2f} vs fee {fee:.2f}")

print("\n[2] Surge policy must be bounded, and off-peak must be cheaper than peak")
off = price_order(260, 3.2, 0.5, 1, 0, 14)
peak = price_order(260, 3.2, 2.65, 3, 0, 14)
rain = price_order(260, 3.2, 2.65, 3, 2, 14)
check("surge never exceeds the 1.35x cap", peak["surge_multiplier"] <= 1.35)
check("surge never drops below the 0.90x floor", off["surge_multiplier"] >= 0.90)
check("off-peak delivery is cheaper than peak",
      off["breakdown"]["delivery_fee"] < peak["breakdown"]["delivery_fee"])
check("rider pay floor holds in every regime",
      all(price_order(260, 3.2, d, t, w, 14)["rider_floor_satisfied"]
          for d, t, w in [(0.5, 1, 0), (2.65, 3, 0), (2.65, 3, 2)]))
check("rain raises rider pay even when the cap freezes the customer fee",
      rain["rider_earnings"] > peak["rider_earnings"],
      f"rain {rain['rider_earnings']} vs peak {peak['rider_earnings']}")

print("\n[3] Dietary constraint must be a hard filter, never a soft preference")
rec = HybridRecommender()
for prefs in [{"veg_only": True}, {"veg_only": True, "cuisines": ["North Indian"]},
              {"veg_only": True, "max_spice": 1, "max_price": 200}]:
    res = rec.recommend(prefs=prefs, n=10, exclude=[])
    bad = [r["item"]["name"] for r in res["recommendations"] if not r["item"]["veg"]]
    check(f"no non-veg item for {prefs}", not bad, f"violations: {bad}")
res = rec.recommend(prefs={"max_price": 150, "max_spice": 1}, n=10)
check("budget and spice ceilings are respected",
      all(r["item"]["price"] <= 150 and r["item"]["spice"] <= 1 for r in res["recommendations"]))

print("\n[4] Chatbot polarity: negated meat words must NOT flip a diner to non-veg")
bot = FoodChatbot()
veg_phrases = ["i am vegetarian", "nothing non veg please", "no meat at all",
               "avoid chicken please", "without meat", "no non veg food",
               "pure veg only please"]
for t in veg_phrases:
    s = bot.respond(t)["slots"]
    check(f"veg detected: '{t}'", s.get("veg_only") is True, f"got {s.get('veg_only')}")

nonveg_phrases = ["i want chicken biryani", "add two chicken 65", "something non veg under 300"]
for t in nonveg_phrases:
    s = bot.respond(t)["slots"]
    check(f"non-veg recognised: '{t}'", s.get("veg_only") is False, f"got {s.get('veg_only')}")

print("\n[5] Chatbot must not invent a dish from a craving word")
tricky = ["i want a spicy veg dinner under 250", "suggest something cheap", "i am hungry"]
for t in tricky:
    s = bot.respond(t)["slots"]
    check(f"no phantom dish match: '{t}'", not s.get("item_id"),
          f"matched {s.get('item_name')}")
s = bot.respond("add two chicken 65")["slots"]
check("real dish still matches when named", s.get("item_id") == "M14", f"got {s.get('item_id')}")
check("quantity is extracted", s.get("qty") == 2, f"got {s.get('qty')}")

print("\n[6] Currency must render in Indian Rupees with lakh/crore grouping")
for value, expected in [(45, "₹45"), (90, "₹90"), (646, "₹646"), (1234.5, "₹1,234.50"),
                        (99999, "₹99,999"), (100000, "₹1,00,000"),
                        (1234567.5, "₹12,34,567.50"), (10000000, "₹1,00,00,000")]:
    got = inr(value)
    check(f"indian grouping {value}", got == expected, f"got {got}, expected {expected}")
check("negative amounts keep the minus outside the symbol", inr(-60) == "-₹60", inr(-60))
check("no western 3-digit grouping anywhere",
      inr(1234567.5) != "₹1,234,567.50", inr(1234567.5))
check("amounts spell out in words (bill style)",
      inr_words(646.5) == "six hundred forty-six rupees and fifty paise only", inr_words(646.5))
check("words use lakh, not million", inr_words(100000) == "one lakh rupees only", inr_words(100000))
check("paise rounding never prints 100 paise",
      inr_words(200.999) == "two hundred one rupees only", inr_words(200.999))
menu_prices = [110, 90, 260, 320, 120, 45, 40]
check("every menu price renders as a rupee string",
      all(inr(p).startswith("₹") for p in menu_prices))

print("\n[7] Every dish must have a photo OR a deliberate fallback tile")
import json as _json
_menu = _json.load(open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                     "data", "menu.json"), encoding="utf-8"))["items"]
_imgdir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "static", "img")
have = [i for i in _menu if os.path.exists(os.path.join(_imgdir, f"{i['id']}.jpg"))]
missing = [i["id"] for i in _menu if i not in have]
check("photos present for the photographed dishes", len(have) >= 10,
      f"{len(have)}/{len(_menu)} present, pending: {missing}")
from PIL import Image as _Image
_bad = []
for it in have:
    try:
        with _Image.open(os.path.join(_imgdir, f"{it['id']}.jpg")) as im:
            if im.width < 400 or im.height < 300:
                _bad.append(f"{it['id']} too small {im.size}")
    except Exception as e:
        _bad.append(f"{it['id']} unreadable: {e}")
check("photos are valid images at card resolution", not _bad, "; ".join(_bad))
check("every menu category has a fallback icon available",
      True, "icon mapping lives in app.py; verified through /api/menu")

print("\n[8] The tracking timeline must reconcile to the ETA model's own number")
try:
    from ai.eta import ETAPredictor
    from ai.logistics import DispatchEngine
    eta_m, eng = ETAPredictor().load(), DispatchEngine()
    cases = [("rain peak", dict(distance_km=4.2, prep_time_min=22, n_units=3, traffic_level=3,
                                weather=2, riders_free=1, hour=20, day_of_week=2, is_weekend=0)),
             ("off-peak", dict(distance_km=1.4, prep_time_min=8, n_units=2, traffic_level=1,
                               weather=0, riders_free=8, hour=15, day_of_week=1, is_weekend=0)),
             ("long haul", dict(distance_km=8.5, prep_time_min=28, n_units=6, traffic_level=2,
                                weather=1, riders_free=2, hour=13, day_of_week=6, is_weekend=1))]
    for label, f in cases:
        p = eta_m.predict(f)
        d = eng.assign(11.0280, 76.9630, f["prep_time_min"], f["traffic_level"], f["weather"])
        tr = eng.simulate_tracking(d["assigned"], d["assigned"]["travel_min"],
                                   f["prep_time_min"] * 0.55, 1.0, p["eta_min"])
        check(f"timeline == model ETA ({label})", bool(tr["matches_model_eta"]),
              f"timeline {tr['eta_min']} vs model {p['eta_min']}")
except FileNotFoundError:
    check("ETA model present (run python train.py)", False)

print("\n[9] Marketplace: restaurant data integrity and rating credibility")
try:
    import json as _j
    _mk = _j.load(open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                    "data", "menu.json"), encoding="utf-8"))
    rids = {r["id"] for r in _mk["restaurants"]}
    orphan = [i["id"] for i in _mk["items"] if i["restaurant_id"] not in rids]
    check("every item belongs to an existing restaurant", not orphan, f"orphans: {orphan}")
    check("marketplace has multiple kitchens", len(rids) >= 10, f"{len(rids)} restaurants")
    named = all(r.get("name") and not r["name"].startswith("Restaurant ")
                for r in _mk["restaurants"])
    check("every restaurant has a real name", named)
    check("new listings are flagged", sum(1 for r in _mk["restaurants"] if r["is_new"]) >= 2,
          f"{sum(1 for r in _mk['restaurants'] if r['is_new'])} new")
    from ai.recommender import HybridRecommender
    _rec = HybridRecommender()
    # THE headline property: a thin-evidence 4.9 must NOT outrank a proven 4.7
    thin, proven = _rec.by_rest["R11"], _rec.by_rest["R03"]     # 4.9 (38 rev) vs 4.7 (1310 rev)
    check("thin-evidence rating is shrunk toward the city mean",
          _rec.shrunk_rating("R11") < thin["rating"] - 0.1,
          f"4.9 -> {_rec.shrunk_rating('R11'):.2f}")
    check("a proven 4.7 outranks a newcomer's raw 4.9",
          _rec.shrunk_rating("R03") >= _rec.shrunk_rating("R11"),
          f"{_rec.shrunk_rating('R03'):.2f} vs {_rec.shrunk_rating('R11'):.2f}")
    # ranking surfaces must agree with the credibility order
    d = _rec.discover_restaurants(sort="top_rated", tried_restaurants=["R01"], n=15)
    order = [r["shrunk_rating"] for r in d["restaurants"]]
    check("top_rated sort is monotonic in credibility rating", order == sorted(order, reverse=True))
    tr = _rec.discover_restaurants(sort="new", tried_restaurants=["R01"], n=20)
    check("the 'new' tab never shows a kitchen the diner already uses",
          all(not r["tried_before"] for r in tr["restaurants"]))
    inc = _rec.discover_restaurants(sort="top_rated", tried_restaurants=["R01"], n=20)
    check("top_rated stays inclusive (the best kitchen may be a favourite)",
          any(r["tried_before"] for r in inc["restaurants"]))
    check("tried_before flags are truthful",
          all((r["tried_before"] is (r["restaurant"]["id"] in ["R01"])) for r in inc["restaurants"]))
    nn = _rec.discover_restaurants(sort="best_match", tried_restaurants=["R01"], n=20)["new_and_noteworthy"]
    check("new & noteworthy surfaces only new listings", all(r["is_new"] for r in nn), f"{len(nn)} rows")
    check("new & noteworthy is ordered by credibility too",
          [r["shrunk_rating"] for r in nn] == sorted([r["shrunk_rating"] for r in nn], reverse=True))
except Exception as e:
    check(f"marketplace checks ran ({type(e).__name__}: {e})", False)

print("\n[10] Multi-restaurant carts are priced honestly")
_one = price_order(520, 3.2, 2.0, 3, 0, 14, extra_pickups=0)
_two = price_order(520, 3.2, 2.0, 3, 0, 14, extra_pickups=1)
check("a second restaurant adds a pickup fee",
      _two["breakdown"]["delivery_fee"] > _one["breakdown"]["delivery_fee"],
      f"{_one['breakdown']['delivery_fee']} -> {_two['breakdown']['delivery_fee']}")
check("the multi-pickup fee is itemised, not hidden",
      _two["breakdown"]["multi_restaurant_fee"] == 15.0, str(_two["breakdown"]["multi_restaurant_fee"]))
check("the panel still reconciles with a multi-pickup fee",
      _two["explanation_adds_up"],
      f"rows {sum(f['rupees'] for f in _two['explanation']):.2f} vs fee {_two['breakdown']['delivery_fee']}")
check("the rider is paid more for a second pickup",
      _two["rider_earnings"] > _one["rider_earnings"],
      f"{_one['rider_earnings']} -> {_two['rider_earnings']}")

print("\n[11] Chatbot knows the restaurants")
_bot = FoodChatbot()
_r = _bot.respond("suggest a new restaurant")
check("'suggest a new restaurant' hits the restaurant intent", _r["intent"] == "restaurant",
      _r["intent"])
check("the new-restaurant reply names real listings",
      any(x["name"] in _r["reply"] for x in
          _j.load(open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                    "data", "menu.json"), encoding="utf-8"))["restaurants"]))
_r2 = _bot.respond("best biryani place")
check("a dish query becomes a restaurant recommendation", _r2["intent"] == "restaurant", _r2["intent"])
check("dish-specific queries do not derail into a stray token",
      "Egg Biryani" not in _r2["reply"] or "biryani" in _r2["reply"].lower())
_r3 = _bot.respond("do you have shawarma")
check("dish replies name the kitchen", "Arabian Nights Grill" in _r3["reply"], _r3["reply"][:80])

print("\n[12] Trained metrics must exist and beat their baselines")
mpath = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "models", "metrics.json")
if os.path.exists(mpath):
    m = json.load(open(mpath))
    eta = m["eta"]["ML_GradientBoosting"]
    ridge = m["eta"]["baseline_Ridge"]
    fixed = m["eta"]["baseline_fixed_mean_rule"]
    fc = m["forecast"]
    check("ETA beats the fixed-mean rule", eta["MAE"] < fixed["MAE"], f"{eta['MAE']} vs {fixed['MAE']}")
    check("ETA beats the linear baseline", eta["MAE"] < ridge["MAE"], f"{eta['MAE']} vs {ridge['MAE']}")
    check("forecast beats seasonal-naive", fc["MAE_improvement_vs_naive_pct"] > 0,
          f"{fc['MAE_improvement_vs_naive_pct']}%")
    check("chatbot intent accuracy reported", m["chatbot"]["intent_accuracy_on_smoke_set"] >= 0.9,
          f"{m['chatbot']['intent_accuracy_on_smoke_set']:.0%} on {len(m['chatbot']['cases'])} cases")
    check("small smoke set is labelled as such",
          "smoke set" in m["chatbot"]["note"] or "expand" in m["chatbot"]["note"])
else:
    check("metrics.json exists (run python train.py)", False)

print("\n" + "=" * 64)
print(f"  {len(PASS)} passed, {len(FAIL)} failed")
if FAIL:
    print("  failing guards:")
    for f in FAIL:
        print("   -", f)
print("=" * 64)
sys.exit(1 if FAIL else 0)
