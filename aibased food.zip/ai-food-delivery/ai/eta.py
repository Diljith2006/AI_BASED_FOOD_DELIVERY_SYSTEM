"""
ai/eta.py — Sprint 2 deliverable: ML-based delivery ETA prediction
------------------------------------------------------------------
Problem : given an order + live context, predict minutes-to-doorstep.
Model   : Gradient Boosting regression (3 heads: point, p10, p90 quantile)
Baseline: Ridge linear regression + a fixed "orders take 35 min" rule
Proof   : 5-fold cross-validation MAE / RMSE / R^2 vs both baselines
Explain : per-prediction contributions from a linear surrogate (what-if XAI)
"""
from __future__ import annotations

import os, pickle
import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.linear_model import Ridge
from sklearn.model_selection import KFold, cross_val_predict
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

FEATURES = [
    "distance_km", "prep_time_min", "n_units", "traffic_level", "weather",
    "riders_free", "hour_sin", "hour_cos", "dow_sin", "dow_cos",
    "is_weekend", "dist_x_traffic", "load_pressure",
]
MODEL_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                          "models", "eta_model.pkl")


def build_features(order: dict) -> dict:
    """Single source of truth for feature engineering — training and serving
    call the same function, which removes train/serve skew (a classic bug)."""
    hour = float(order.get("hour", 13))
    dow = float(order.get("day_of_week", 2))
    dist = float(order.get("distance_km", 3.0))
    traffic = float(order.get("traffic_level", 2))
    riders = float(order.get("riders_free", 3))
    units = float(order.get("n_units", 2))
    f = {
        "distance_km": dist,
        "prep_time_min": float(order.get("prep_time_min", 15.0)),
        "n_units": units,
        "traffic_level": traffic,
        "weather": float(order.get("weather", 0)),
        "riders_free": riders,
        "hour_sin": np.sin(2 * np.pi * hour / 24),
        "hour_cos": np.cos(2 * np.pi * hour / 24),
        "dow_sin": np.sin(2 * np.pi * dow / 7),
        "dow_cos": np.cos(2 * np.pi * dow / 7),
        "is_weekend": float(order.get("is_weekend", int(dow >= 5))),
        "dist_x_traffic": dist * traffic,          # interaction: far + jam = worse
        "load_pressure": max(0.0, 3.0 - riders) + 0.5 * max(0.0, units - 3),
    }
    return f


class ETAPredictor:
    """Trains once, then serves fast predictions with uncertainty bounds."""

    def __init__(self):
        self.point = None
        self.lo = None
        self.hi = None
        self.surrogate = None                  # Ridge, used only for explanations
        self.feature_mean = None
        self.metrics: dict = {}
        self.residual_sigma = 2.5

    # ------------------------------------------------------------- training
    def train(self, df: pd.DataFrame, save: bool = True) -> dict:
        X = pd.DataFrame([build_features(r) for r in df.to_dict("records")])[FEATURES]
        y = df["actual_eta_min"].to_numpy(dtype=float)
        self.feature_mean = X.mean()

        # --- honest validation: out-of-fold predictions, never on train data
        kf = KFold(n_splits=5, shuffle=True, random_state=42)
        gbr = GradientBoostingRegressor(
            n_estimators=300, learning_rate=0.05, max_depth=3,
            subsample=0.9, random_state=42)
        oof_ml = cross_val_predict(gbr, X, y, cv=kf)

        ridge = Ridge(alpha=1.0)
        oof_ridge = cross_val_predict(ridge, X, y, cv=kf)
        oof_rule = np.full_like(y, y.mean())        # "always 26 min" rule baseline

        def sc(yt, yp):
            return {
                "MAE": round(float(mean_absolute_error(yt, yp)), 2),
                "RMSE": round(float(np.sqrt(mean_squared_error(yt, yp))), 2),
                "R2": round(float(r2_score(yt, yp)), 3),
            }

        self.metrics = {
            "n_train": int(len(y)),
            "target_mean_min": round(float(y.mean()), 1),
            "ML_GradientBoosting": sc(y, oof_ml),
            "baseline_Ridge": sc(y, oof_ridge),
            "baseline_fixed_mean_rule": sc(y, oof_rule),
            "cv_folds": 5,
            "in_sample_MAE_after_refit": None,
        }
        self.residual_sigma = float(np.std(y - oof_ml))

        # --- final fit on all data for serving
        gbr.fit(X, y)
        self.point = gbr
        self.lo = GradientBoostingRegressor(loss="quantile", alpha=0.10, n_estimators=250,
                                            learning_rate=0.05, max_depth=3, random_state=42).fit(X, y)
        self.hi = GradientBoostingRegressor(loss="quantile", alpha=0.90, n_estimators=250,
                                            learning_rate=0.05, max_depth=3, random_state=42).fit(X, y)
        self.surrogate = Ridge(alpha=1.0).fit(X, y)
        self.metrics["in_sample_MAE_after_refit"] = round(
            float(mean_absolute_error(y, self.point.predict(X))), 2)
        # guard against split-conformal crossing
        self.metrics["feature_importance"] = {
            k: round(float(v), 3) for k, v in
            sorted(zip(FEATURES, gbr.feature_importances_), key=lambda t: -t[1])
        }
        if save:
            os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
            with open(MODEL_PATH, "wb") as f:
                pickle.dump(self, f)
        return self.metrics

    # ------------------------------------------------------------- serving
    def predict(self, order: dict) -> dict:
        if self.point is None:
            self.load()
        f = build_features(order)
        X = pd.DataFrame([f])[FEATURES]
        eta = float(self.point.predict(X)[0])
        lo = float(self.lo.predict(X)[0])
        hi = float(self.hi.predict(X)[0])
        eta = float(np.clip(eta, 8.0, 90.0))
        lo = float(np.clip(min(lo, eta - 1.5), 6.0, eta - 1.0))
        hi = float(np.clip(max(hi, eta + 1.5), eta + 1.0, 110.0))

        # local explanation: linear surrogate contribution of each feature
        # contribution_i = coef_i * (x_i - mean_i)   (positive => pushes ETA up)
        contrib = []
        for i, name in enumerate(FEATURES):
            c = float(self.surrogate.coef_[i] * (f[name] - self.feature_mean[name]))
            contrib.append({"feature": name, "impact_min": round(c, 2)})
        contrib.sort(key=lambda d: -abs(d["impact_min"]))

        return {
            "eta_min": round(eta, 1),
            "eta_range": [round(lo, 1), round(hi, 1)],
            "band_label": "p10-p90 (80% interval)",
            "confidence": "high" if self.metrics else "unknown",
            "contributions": contrib[:7],
            "model": "GradientBoosting + quantile p10/p90 heads",
            "cv_mae_min": self.metrics.get("ML_GradientBoosting", {}).get("MAE"),
            "features_used": f,
        }

    # -------------------------------------------------------------- persist
    def save(self):
        os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
        with open(MODEL_PATH, "wb") as f:
            pickle.dump(self, f)

    def load(self):
        if not os.path.exists(MODEL_PATH):
            raise FileNotFoundError("ETA model not trained yet — run: python train.py")
        with open(MODEL_PATH, "rb") as fh:
            other = pickle.load(fh)
        self.__dict__.update(other.__dict__)
        return self
