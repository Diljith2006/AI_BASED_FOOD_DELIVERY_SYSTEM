"""
ai/chatbot.py — Sprint 3 deliverable: natural-language ordering assistant
-------------------------------------------------------------------------
Two-stage NLU, deliberately classical (no LLM API => runs offline, free, and
every decision is inspectable in a viva):

  STAGE 1  Intent classification
           TF-IDF (word 1-2 grams) + Logistic Regression, trained on a curated
           phrase bank of ~200 utterances across 13 intents.  We report the
           confidence and the runner-up intent, so wrong guesses are visible.

  STAGE 2  Slot filling
           Rule/regex extraction of: cuisine, veg flag, spice level, price
           ceiling, quantity, meal category, dish name (fuzzy matched against
           the live menu with difflib + token overlap).

The dialogue manager is stateless: the client sends its cart, the server sends
back *actions* ("add_item", "clear_cart") plus a reply.  No session store means
it survives restarts and scales horizontally.
"""
from __future__ import annotations

import json, os, re
from difflib import SequenceMatcher

from ai.currency import inr          # single source of truth for rupee rendering

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")

with open(os.path.join(DATA, "menu.json"), encoding="utf-8") as f:
    MARKET = json.load(f)
MENU = MARKET["items"]
RESTAURANTS = MARKET["restaurants"]
BY_ID = {it["id"]: it for it in MENU}
BY_RESTAURANT = {r["id"]: r for r in RESTAURANTS}
CITY_MEAN_RATING = sum(r["rating"] for r in RESTAURANTS) / len(RESTAURANTS)
SHRINK_M = 50.0


def credibility(r: dict) -> float:
    """Same Bayesian shrinkage the recommender uses — one definition of
    'well rated' across the whole product."""
    v, R = float(r["rating_count"]), float(r["rating"])
    return (v * R + SHRINK_M * CITY_MEAN_RATING) / (v + SHRINK_M)


def restaurants_serving(dish_word: str | None = None, cuisine: str | None = None) -> list[dict]:
    """Restaurants serving a specific dish word and/or cuisine, best first.

    Dish-word matches are ranked ABOVE cuisine-only matches: asking for "filter
    coffee" should surface the coffee specialist, not whichever kitchen happens
    to serve any beverage with a slightly better rating.
    """
    out = []
    for r in RESTAURANTS:
        items = [i for i in MENU if i["restaurant_id"] == r["id"]]
        dish_hits = [i for i in items if dish_word and dish_word in i["name"].lower()]
        cuisine_hit = cuisine is not None and any(i["cuisine"] == cuisine for i in items)
        if not dish_hits and not cuisine_hit:
            continue
        relevance = credibility(r)
        if dish_hits:
            # the dish exists here; how much does this kitchen actually sell it?
            relevance += 0.6 * max(i["popular_base"] for i in dish_hits)
        if cuisine_hit:
            relevance += 0.15
        out.append({"restaurant": r, "relevance": relevance,
                    "matched_dish": (max(dish_hits, key=lambda i: i["popular_base"])["name"]
                                     if dish_hits else None)})
    out.sort(key=lambda d: -d["relevance"])
    return out

STOP = {"i", "want", "a", "an", "the", "me", "some", "for", "please", "to", "of",
        "with", "and", "can", "you", "get", "would", "like", "my", "is", "it", "do"}

# --------------------------------------------------------------- phrase bank
PHRASE_BANK = {
    "greet": ["hi", "hello", "hey there", "good morning", "good evening", "vanakkam",
              "hi buddy", "hello there", "namaste", "yo", "start", "hi can you help me"],
    "menu": ["show me the menu", "what do you have", "list all dishes", "menu please",
             "what is on the menu", "display the full menu", "show all food items",
             "what can i order", "see the menu card", "show items"],
    "recommend": ["what should i eat", "recommend something", "suggest a dish for me",
                  "i am hungry what do you suggest", "surprise me", "best dish here",
                  "what is popular", "give me a recommendation", "help me decide what to order",
                  "what do you recommend for dinner", "suggest something tasty",
                  "i cannot decide what to eat", "top rated dish please",
                  "i want a spicy veg dinner under 250", "recommend a veg dish under 200",
                  "suggest something spicy for dinner", "i want something spicy under 300",
                  "recommend a budget friendly veg meal", "what is good for dinner tonight",
                  "suggest a veg dish please", "i want a quick lunch suggestion",
                  "recommend something spicy and vegetarian", "what should i order under 250",
                  "give me a dinner idea", "suggest something cheap and filling",
                  "i want a healthy option", "what is best for breakfast"],
    "search": ["do you have biryani", "looking for dosa", "i want chicken shawarma",
               "search for noodles", "is there any paneer dish", "find me a dessert",
               "show me chinese food", "any mutton item", "do you serve coffee",
               "show south indian dishes", "i feel like eating parotta", "got any veg starters"],
    "add_to_cart": ["add biryani to my cart", "i will take one dosa", "order two chicken 65",
                    "put one ghee roast in the cart", "i want to order butter chicken",
                    "add a filter coffee", "give me one shawarma roll please",
                    "please add paneer butter masala", "two garlic naan please",
                    "i will order the mutton curry", "add this to cart", "buy one gulab jamun"],
    "remove_from_cart": ["remove the dosa", "delete biryani from cart", "take out the coffee",
                         "i do not want the naan anymore", "clear my cart", "empty the cart",
                         "cancel the last item", "remove item", "drop the dessert"],
    "view_cart": ["what is in my cart", "show my cart", "how many items did i add",
                  "let me see my order", "view cart please", "what have i selected",
                  "cart summary", "my basket"],
    "checkout": ["place my order", "checkout now", "confirm the order", "pay and order",
                 "i am done ordering", "complete my order", "finalise order", "checkout please"],
    "restaurant": ["which restaurant is best", "show me top rated restaurants",
                   "suggest a new restaurant", "recommend a restaurant near me",
                   "any new restaurants on sizzle", "best biryani place",
                   "where can i get good biryani", "which place has the best dosa",
                   "show restaurants near peelamedu", "top rated places to order from",
                   "who makes the best filter coffee", "new restaurants please",
                   "which kitchen is highly rated", "best seafood restaurant",
                   "list the restaurants", "how many restaurants do you have"],
    "track": ["where is my order", "track my delivery", "how far is the rider",
              "order status please", "is my food coming", "when will the rider arrive",
              "track order 12", "where is my food right now", "rider location"],
    "eta": ["how long will delivery take", "what is the eta", "how many minutes to deliver",
            "when will my food arrive", "delivery time please", "how late will it be",
            "estimated arrival time", "how long for delivery to peelamedu"],
    "price": ["why is the price higher", "how much does biryani cost", "is there a surcharge",
              "why did the price increase", "what is the total cost", "any discount today",
              "why is delivery expensive now", "cheapest item please", "price of chicken 65"],
    "diet": ["i am vegetarian", "only veg food please", "no non veg", "i do not eat meat",
             "show me vegan options", "anything without onion and garlic", "jain food available",
             "i want pure veg dishes", "please filter veg only", "i never eat chicken or mutton",
             "my family is vegetarian", "switch the menu to veg only"],
    "thanks": ["thank you", "thanks a lot", "great thanks", "appreciate it", "thanks buddy",
               "bye", "goodbye", "see you", "that is all", "ok thanks"],
}
FALLBACK_HINTS = ["how can i help", "sorry i did not get that", "i can help you order food"]

# Words that describe a *craving or constraint*, not a dish name.  Without this
# list "veg dinner under 250" would fuzzy-match "Veg Burger" and silently add the
# wrong food — the classic slot-filling failure this project must avoid.
GENERIC_TERMS = {
    "veg", "nonveg", "vegetarian", "vegan", "food", "dish", "dishes", "item", "items",
    "order", "meal", "dinner", "lunch", "breakfast", "snack", "snacks", "dessert",
    "desserts", "starter", "starters", "main", "beverage", "beverages", "drink", "drinks",
    "spicy", "mild", "cheap", "budget", "healthy", "quick", "something", "anything",
    "south", "north", "indian", "chinese", "arabian", "fast", "side", "combo", "classic",
    "signature", "popular", "best", "tasty", "filling", "light", "cold", "rich",
}

# ------------------------------------------------------------------ slot lexicons
CUISINE_SYN = {
    "south indian": ["south indian", "tamil", "chettinad", "kongunadu", "madurai", "dosa", "idli", "pongal"],
    "north indian": ["north indian", "punjabi", "butter chicken", "paneer", "naan", "roti", "dal"],
    "chinese": ["chinese", "indo chinese", "noodles", "manchurian", "schezwan", "fried rice", "hakka"],
    "arabian": ["arabian", "shawarma", "alfaham", "al faham", "kuboos", "hummus", "middle eastern"],
    "fast food": ["fast food", "burger", "fries", "sandwich"],
    "dessert": ["dessert", "sweet", "gulab jamun", "payasam", "kheer"],
    "beverage": ["beverage", "drink", "coffee", "chai", "tea", "cooler"],
}
SPICE_WORDS = {"mild": 1, "not spicy": 1, "less spicy": 1, "medium spicy": 2,
               "spicy": 3, "very spicy": 3, "hot and spicy": 3, "extra spicy": 3,
               "piping hot": 2, "fiery": 3}
VEG_POS = ["veg ", " veg", "vegetarian", "pure veg", "no meat", "no non veg", "no non-veg",
           "nothing non veg", "nothing non-veg", "avoid non veg", "without meat", "no chicken",
           "without chicken", "without mutton", "no mutton", "no fish", "no egg", "plant based", "jain"]
VEG_NEG = ["non veg", "non-veg", "chicken", "mutton", "fish", "prawn", "egg", "meat", "beef"]
QTY_WORDS = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "a": 1, "an": 1,
             "1": 1, "2": 2, "3": 3, "4": 4, "5": 5, "couple of": 2, "pair of": 2}


def tokenise(t: str) -> list[str]:
    return [w for w in re.findall(r"[a-z0-9]+", t.lower()) if w not in STOP]


class FoodChatbot:
    def __init__(self):
        texts, labels = [], []
        for intent, phrases in PHRASE_BANK.items():
            for p in phrases:
                texts.append(p)
                labels.append(intent)
        # augmentation: "please " / "can you " prefixes double the surface variety
        aug_t, aug_l = [], []
        for p, l in zip(texts, labels):
            aug_t.append("please " + p); aug_l.append(l)
            aug_t.append("can you " + p); aug_l.append(l)
        self.intents = sorted(PHRASE_BANK)
        self.clf = Pipeline([
            ("tfidf", TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True, min_df=1)),
            ("lr", LogisticRegression(C=6.0, max_iter=2000)),
        ])
        self.clf.fit(texts + aug_t, labels + aug_l)
        self.n_train_utterances = len(texts + aug_t)

        # dish index: token -> item ids
        self.dish_tokens: dict[str, set[str]] = {}
        for it in MENU:
            toks = set(tokenise(it["name"])) | {it["cuisine"].lower(), it["category"].lower()}
            toks |= {t.lower() for t in it["tags"]}
            for t in toks:
                self.dish_tokens.setdefault(t, set()).add(it["id"])
        # train the vegetarian classifier? no — deterministic rules, auditable.

    # ------------------------------------------------------------ slot filling
    def extract_slots(self, text: str) -> dict:
        low = " " + text.lower().strip() + " "
        slots: dict = {}

        for cuisine, syns in CUISINE_SYN.items():
            if any(s in low for s in syns):
                slots["cuisine"] = cuisine.title()
                break
        for w, lvl in SPICE_WORDS.items():
            if w in low:
                slots["max_spice"] = lvl
                slots["spice_word"] = w
                break
        # Negation-aware veg detection.  "nothing non veg" contains the string
        # "non veg", so a naive keyword scan flips the diner to non-vegetarian —
        # the classic polarity bug.  Negated mentions are stripped before the
        # negative lexicon is consulted.
        negated_meat = re.search(
            r"\b(no|not|without|avoid|nothing|never|dont|don't|cannot|can't)\s+(?:\w+\s+)?"
            r"(non[ -]?veg|nonveg|meat|chicken|mutton|fish|egg|beef|prawn)\w*", low)
        low_neg = re.sub(
            r"\b(no|not|without|avoid|nothing|never|dont|don't|cannot|can't)\s+(?:\w+\s+)?"
            r"(non[ -]?veg|nonveg|meat|chicken|mutton|fish|egg|beef|prawn)\w*", " ", low)
        # A *negated* meat/non-veg mention is itself positive evidence for veg
        # ("avoid chicken", "no egg"), so it is counted alongside the phrase list.
        if (any(v in low for v in VEG_POS) or negated_meat) \
                and not any(n in low_neg for n in VEG_NEG):
            slots["veg_only"] = True
        elif any(n in low_neg for n in VEG_NEG):
            slots["veg_only"] = False

        m = re.search(r"(?:under|below|less than|upto|up to|within|max|budget of)\s*(?:rs\.?|inr|₹)?\s*(\d{2,4})", low)
        if m:
            slots["max_price"] = int(m.group(1))
        m2 = re.search(r"(?:rs\.?|inr|₹)\s*(\d{2,4})", low)
        if not m and m2:
            slots["max_price"] = int(m2.group(1))
        m = re.search(r"(?:order\s+)?(one|two|three|four|five|\d+)\s+(?=[a-z])", low)
        if m:
            q = QTY_WORDS.get(m.group(1).strip(), None)
            if q is None:
                try:
                    q = int(m.group(1))
                except ValueError:
                    q = None
            if q:
                slots["qty"] = q
        m = re.search(r"\border\s*#?\s*(o?\d{3,6})\b", low) or re.search(r"\b(o\d{4,5})\b", low)
        if m:
            oid = m.group(1).upper()
            slots["order_id"] = oid if oid.startswith("O") else "O" + oid

        # dish matching — score each candidate item by fuzzy + token evidence.
        # Evidence must include a DISH-SPECIFIC token: matching on "veg", "spicy"
        # or "dinner" alone would add the wrong dish to the cart.
        toks = set(tokenise(text))
        informative = toks - GENERIC_TERMS
        scored = []
        for it in MENU:
            name = it["name"].lower()
            name_toks = set(tokenise(it["name"]))
            name_overlap = len(name_toks & informative)
            ratio = SequenceMatcher(None, " ".join(sorted(informative)), name).ratio()
            specific = name_overlap > 0 or ratio > 0.72
            if not specific:
                continue
            s = ratio * 0.6 + name_overlap * 0.55
            s += 0.25 if it["cuisine"].lower() in low else 0
            s += 0.18 if it["category"].lower() in low else 0
            for t in it["tags"]:
                if t.lower() in low and t.lower() not in GENERIC_TERMS:
                    s += 0.22
            s *= 0.8 + 0.25 * it["popular_base"]      # tie-break toward popular staples
            scored.append((s, it))
        scored.sort(key=lambda t: -t[0])
        if scored and scored[0][0] >= 0.55:
            winner = scored[0][1]
            # an exact name hit is not a guess, so it must not trigger the
            # "did you mean…?" hint — that reads as the bot being unsure of a
            # dish the user typed correctly.
            exact = winner["name"].lower() in low
            slots["item_id"] = winner["id"]
            slots["item_name"] = winner["name"]
            slots["item_exact"] = bool(exact)
            slots["item_confidence"] = 0.98 if exact else round(min(0.95, scored[0][0] / 2.2), 2)
            slots["alternates"] = [
                {"item_id": i["id"], "name": i["name"],
                 "confidence": round(min(0.95, sc / 2.2), 2)}
                for sc, i in scored[1:4] if sc >= 0.55
            ]
        return slots

    # ---------------------------------------------------------------- predict
    def classify(self, text: str) -> dict:
        proba = self.clf.predict_proba([text])[0]
        order = np.argsort(-proba)
        classes = self.clf.classes_
        return {
            "intent": str(classes[order[0]]),
            "confidence": round(float(proba[order[0]]), 3),
            "runner_up": {"intent": str(classes[order[1]]), "confidence": round(float(proba[order[1]]), 3)},
        }

    # ------------------------------------------------------- dialogue manager
    def respond(self, text: str, cart: list[dict] | None = None, prefs: dict | None = None) -> dict:
        cart = cart or []
        prefs = dict(prefs or {})
        clf = self.classify(text)
        slots = self.extract_slots(text)
        intent, conf = clf["intent"], clf["confidence"]
        actions, suggestions = [], []

        # ---- disambiguation rule the classifier alone cannot express:
        # "i am vegetarian" is a *preference statement* (intent = diet) but
        # "i am vegetarian, something spicy under 250" is a *craving request*
        # (intent = recommend) with veg_only as a slot.  Budget/spice words are
        # the signal that separates the two.
        rerouted = None
        craving = ("max_price" in slots) or ("max_spice" in slots)
        if intent == "diet" and craving:
            rerouted, intent = "diet", "recommend"

        # slots also become sticky preferences for the recommender
        for k in ("cuisine", "max_price", "max_spice", "veg_only"):
            if k in slots:
                if k == "cuisine":
                    prefs.setdefault("cuisines", [])
                    if slots[k] not in prefs["cuisines"]:
                        prefs["cuisines"].append(slots[k])
                else:
                    prefs[k] = slots[k]

        if conf < 0.22:
            reply = ("I'm not fully sure I understood that. I can: show the menu, recommend a dish, "
                     "add/remove items, tell you the ETA, explain the price, or track an order. "
                     "Try \"something spicy under 250\".")
            intent = "fallback"
        elif intent == "greet":
            reply = ("Vanakkam! I'm SizzleBot. Tell me a mood, a budget, or a dish — e.g. "
                     "\"recommend a spicy veg dinner under 250\" or \"add chicken 65\".")
        elif intent == "menu":
            reply = f"We have {len(MENU)} dishes across South Indian, North Indian, Chinese, Arabian, " \
                    f"Fast Food, Desserts and Beverages. Filter me with \"veg only\", \"under 200\" " \
                    f"or a cuisine name."
            suggestions = [{"item_id": i["id"], "name": i["name"], "price": i["price"]}
                           for i in _rank(MENU, prefs)[:6]]
        elif intent == "recommend":
            picks = _rank(MENU, prefs)[:3]
            lines = [f"{it['name']} at {it['restaurant_name']} ({inr(it['price'])}, {it['rating']}★)"
                     for it in picks]
            locks = []
            if prefs.get("veg_only"):
                locks.append("veg only")
            if prefs.get("max_price"):
                locks.append(f"under {inr(float(prefs['max_price']))}")
            if "max_spice" in slots:
                locks.append(f"spice level {slots['max_spice']}/3 or lower")
            lead = ("Locking the menu to " + ", ".join(locks) + ". ") if locks else ""
            if rerouted:
                lead += "(You said that as a preference, but I read it as a request — say 'veg filter' to just filter.) "
            reply = lead + "Based on your taste, I'd go with " + "; ".join(lines) + "."
            suggestions = [{"item_id": i["id"], "name": i["name"], "price": i["price"]} for i in picks]
        elif intent == "search":
            iid = slots.get("item_id")
            if iid:
                it = BY_ID[iid]
                veg_txt = "veg" if it["veg"] else "non-veg"
                reply = (f"Yes — {it['name']} ({it['cuisine']}, {veg_txt}, spice {it['spice']}/3) at "
                         f"{it['restaurant_name']} costs {inr(it['price'])} and takes "
                         f"~{it['prep_time_min']} min to cook. Want me to add it?")
                suggestions = [{"item_id": it["id"], "name": it["name"], "price": it["price"]}]
                suggestions += [{"item_id": a["item_id"], "name": a["name"],
                                 "price": BY_ID[a["item_id"]]["price"]} for a in slots.get("alternates", [])[:2]]
            else:
                cand = _rank(MENU, prefs)[:4]
                reply = "I don't stock that exact dish, but close matches are " + \
                        ", ".join(i["name"] for i in cand) + "."
                suggestions = [{"item_id": i["id"], "name": i["name"], "price": i["price"]} for i in cand]
        elif intent == "add_to_cart":
            iid = slots.get("item_id")
            if iid:
                it = BY_ID[iid]
                qty = int(slots.get("qty", 1))
                actions.append({"type": "add_item", "item_id": iid, "qty": qty})
                alt = slots.get("alternates", [])
                reply = f"Added {qty} × {it['name']} ({inr(it['price'] * qty)}). "
                if alt and not slots.get("item_exact") and slots.get("item_confidence", 1) < 0.6:
                    reply += f"If you meant something else, say '{alt[0]['name']}' instead."
                else:
                    reply += "Anything to drink with that?"
                    drinks = [i for i in MENU if i["category"] == "Beverage"][:2]
                    suggestions = [{"item_id": i["id"], "name": i["name"], "price": i["price"]} for i in drinks]
            else:
                reply = "Sure — which dish exactly? Name it and I'll add it straight to your cart."
                suggestions = [{"item_id": i["id"], "name": i["name"], "price": i["price"]}
                               for i in _rank(MENU, prefs)[:4]]
        elif intent == "remove_from_cart":
            iid = slots.get("item_id")
            if "clear" in text.lower() or "empty" in text.lower() or "all" in text.lower():
                actions.append({"type": "clear_cart"})
                reply = "Emptied your cart."
            elif iid:
                actions.append({"type": "remove_item", "item_id": iid})
                reply = f"Removed {BY_ID[iid]['name']} from the cart."
            else:
                reply = "Tell me the dish to remove, or say 'clear cart' to start over."
        elif intent == "view_cart":
            if not cart:
                reply = "Your cart is empty right now. Want a recommendation to get started?"
            else:
                tot = sum(BY_ID[c["item_id"]]["price"] * c.get("qty", 1) for c in cart if c["item_id"] in BY_ID)
                names = ", ".join(f"{c.get('qty',1)}× {BY_ID[c['item_id']]['name']}"
                                  for c in cart if c["item_id"] in BY_ID)
                reply = f"Your cart: {names}. Food total {inr(tot)} (fees and any surge are added at checkout)."
        elif intent == "checkout":
            reply = ("Ready when you are — hit 'Checkout' and I'll price the order live, predict the ETA "
                     "and assign the best rider. I'll show why each number came out the way it did.")
        elif intent == "restaurant":
            want_new = any(w in text.lower() for w in
                           ["new", "newly", "just opened", "recently added", "discover", "explore"])
            cuisine = slots.get("cuisine")
            # which word in the utterance actually names the food?  Prefer the
            # longest informative token, so "best biryani place" asks about
            # BIRYANI rather than latching onto the first word of "Egg Biryani".
            informative = [w for w in tokenise(text) if w not in GENERIC_TERMS and len(w) > 3]
            dish_word = None
            for w in sorted(informative, key=len, reverse=True):
                if any(w in i["name"].lower() for i in MENU):
                    dish_word = w
                    break
            scored = restaurants_serving(dish_word, cuisine)
            if not scored:
                scored = [{"restaurant": r, "relevance": credibility(r), "matched_dish": None}
                          for r in sorted(RESTAURANTS, key=lambda r: -credibility(r))]
            matched_topic = next((c["matched_dish"] for c in scored if c.get("matched_dish")), None)
            cands = [c["restaurant"] for c in scored]
            if want_new:
                news = sorted([r for r in cands if r["is_new"]], key=lambda r: -credibility(r))
                if news:
                    lines = [f"{r['name']} ({r['rating']}★ from just {r['rating_count']} ratings, "
                             f"{r['locality']})" for r in news[:3]]
                    reply = ("Newly onboarded kitchens: " + "; ".join(lines) +
                             ". Few reviews so far — the credibility rating pulls them toward the city "
                             "average (4.53★) until they earn more, so don't read 4.9★ as proven yet.")
                    suggestions = [{"item_id": next(i["id"] for i in MENU if i["restaurant_id"] == r["id"]),
                                    "name": f"{r['name']} — {r['signature_dish'] or r['cuisine']}",
                                    "price": next(i["price"] for i in MENU if i["restaurant_id"] == r["id"])}
                                   for r in news[:3]]
                else:
                    reply = "No brand-new listings match that right now."
            else:
                top = cands[:3]
                lines = [f"{r['name']} ({r['rating']}★, {r['rating_count']} ratings → credibility "
                         f"{credibility(r):.2f})" for r in top]
                topic = (f" for {matched_topic or dish_word}" if (matched_topic or dish_word)
                         else (f" for {cuisine}" if cuisine else ""))
                reply = (f"Best-rated{topic}: " + "; ".join(lines) +
                         ". I rank on the credibility rating, not the raw star average, so a 4.9★ "
                         "from a handful of reviews doesn't outrank a proven 4.7★.")
                suggestions = [{"item_id": next(i["id"] for i in MENU if i["restaurant_id"] == r["id"]),
                                "name": f"{r['name']} — order now", "price": 0} for r in top]
        elif intent == "track":
            oid = slots.get("order_id", "your order")
            reply = (f"{oid} is with a rider and heading your way. Open the Tracking tab and I'll show the "
                     f"live ETA band plus the rider's remaining distance.")
        elif intent == "eta":
            reply = ("Delivery ETA depends on cook time, distance, traffic, weather and how many riders "
                     "are free. My model averages ~4 min error out-of-fold — place the order and I'll "
                     "give you a live p10–p90 band.")
        elif intent == "price":
            reply = ("The price = dish cost + platform fee + delivery fee × surge, where surge rises with "
                     "live demand, traffic and rain. It is legally capped at 1.35× here and I list every "
                     "factor in rupee terms in the Price breakdown panel — no hidden multipliers.")
            suggestions = [{"item_id": i["id"], "name": i["name"], "price": i["price"]}
                           for i in sorted(MENU, key=lambda x: x["price"])[:3]]
        elif intent == "diet":
            veg = [i for i in MENU if i["veg"]]
            reply = (f"Noted — locking the menu to vegetarian ({len(veg)} of {len(MENU)} dishes). "
                     f"Ask me for 'something spicy' or 'under 200' to narrow it further.")
            suggestions = [{"item_id": i["id"], "name": i["name"], "price": i["price"]} for i in veg[:5]]
        elif intent == "thanks":
            reply = "Anytime! Enjoy your meal. 🍽️"
        else:
            reply = FALLBACK_HINTS[0] + ". Try \"recommend something spicy\" or \"add ghee roast dosa\"."
            intent = "fallback"

        return {
            "reply": reply, "intent": intent, "confidence": conf,
            "runner_up": clf["runner_up"], "slots": slots, "actions": actions,
            "suggestions": suggestions, "prefs_after": prefs,
            "nlu_meta": {"vectoriser": "TF-IDF word 1-2 gram", "classifier": "LogisticRegression",
                         "trained_utterances": self.n_train_utterances,
                         "n_intents": len(self.intents)},
        }


def _rank(items: list[dict], prefs: dict) -> list[dict]:
    """Small helper shared by several intents: taste-aware ranking."""
    cuis = set(prefs.get("cuisines") or [])
    out = []
    for it in items:
        if prefs.get("veg_only") and not it["veg"]:
            continue
        if prefs.get("max_price") and it["price"] > float(prefs["max_price"]):
            continue
        if prefs.get("max_spice") is not None and it["spice"] > int(prefs["max_spice"]):
            continue
        s = it["popular_base"] * 1.2 + it["rating"] / 5
        if cuis and it["cuisine"] in cuis:
            s += 0.8
        out.append((s, it))
    out.sort(key=lambda t: -t[0])
    return [it for _, it in out] or items[:6]
