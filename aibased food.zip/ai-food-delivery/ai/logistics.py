"""
ai/logistics.py — Sprint 5 deliverable: smart rider dispatch & live tracking
----------------------------------------------------------------------------
Assignment is a constrained decision, not "nearest wins":

  score = w_d·d_eta + w_a·active_orders + w_r·(5 − rating) + w_v·vehicle_penalty
  hard rejects: active_orders ≥ capacity, ETA worse than 1.6× the best option,
                food waiting longer than the rider's travel time

A greedy assignment is used because with ≤ hundreds of riders it is within a
few percent of the optimal ILP solution and returns in microseconds — the
right engineering trade-off at this scale (documented in the design log).
"""
from __future__ import annotations

import json, math, os
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")


def haversine_km(a, b):
    R = 6371.0
    p1, p2 = math.radians(a[0]), math.radians(b[0])
    dp = p2 - p1
    dl = math.radians(b[1] - a[1])
    h = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * R * math.asin(math.sqrt(h))


class DispatchEngine:
    W_DISTANCE, W_LOAD, W_RATING, W_VEHICLE = 1.0, 1.15, 0.45, 0.35
    RIDER_CAPACITY = 3

    def __init__(self):
        with open(os.path.join(DATA, "riders.json"), encoding="utf-8") as f:
            self.riders = json.load(f)
        rng = np.random.default_rng(7)
        for r in self.riders:
            r["_jitter_lat"] = rng.normal(0, 0.0015)
            r["_jitter_lng"] = rng.normal(0, 0.0015)

    def _reject_reason(self, r, travel_km, best_km, prep_done: bool):
        if r["active_orders"] >= self.RIDER_CAPACITY:
            return f"at capacity ({r['active_orders']}/{self.RIDER_CAPACITY} active)"
        if best_km > 0 and travel_km > 1.6 * best_km:
            return f"too far ({travel_km:.1f} km vs best {best_km:.1f} km)"
        if r["vehicle"] == "cycle" and travel_km > 4.0:
            return "cycle cannot cover this distance in time"
        if prep_done and travel_km > 6.5:
            return "food would go cold before arrival"
        return None

    def assign(self, drop_lat: float, drop_lng: float, prep_time_min: float,
               traffic_level: int = 2, weather: int = 0) -> dict:
        scored, rejected = [], []
        # candidate distances first (for the "too far" relative filter)
        dists = []
        for r in self.riders:
            lat = r["lat"] + r["_jitter_lat"]
            lng = r["lng"] + r["_jitter_lng"]
            dists.append(haversine_km((lat, lng), (drop_lat, drop_lng)) * 1.35)  # road factor
        best_km = min(dists) if dists else 1.0

        for r, km in zip(self.riders, dists):
            speed = {"bike": 24.0, "scooter": 19.0, "cycle": 9.0}[r["vehicle"]]
            travel_min = km / speed * 60.0 * (1 + 0.18 * (traffic_level - 1)) * (1 + 0.15 * weather)
            prep_done = travel_min >= prep_time_min
            # if food is ready before the rider arrives, the rider waits; the
            # ride time is what matters for the customer, so keep travel_min
            score = (self.W_DISTANCE * travel_min
                     + self.W_LOAD * r["active_orders"] * 4.2
                     + self.W_RATING * (5.0 - r["rating"]) * 6.0
                     + self.W_VEHICLE * (3.0 if r["vehicle"] == "cycle" else 0.0))
            reason = self._reject_reason(r, km, best_km, prep_done)
            row = {
                "rider_id": r["rider_id"], "name": r["name"], "vehicle": r["vehicle"],
                "rating": r["rating"], "active_orders": r["active_orders"],
                "distance_km": round(km, 2), "travel_min": round(travel_min, 1),
                "score": round(float(score), 2),
                "food_ready_before_pickup": prep_done,
            }
            if reason:
                row["rejected_because"] = reason
                rejected.append(row)
            else:
                scored.append(row)

        scored.sort(key=lambda d: d["score"])
        rejected.sort(key=lambda d: d["score"])
        if not scored:
            # graceful degradation: pick the least-loaded rider rather than fail
            scored = sorted(rejected, key=lambda d: (d["active_orders"], d["score"]))
            note = "all riders busy — least-loaded selected"
        else:
            note = "score = travel time + load + rating + vehicle penalty"

        champ = scored[0]
        if champ["distance_km"] < 2.0:
            why = (f"{champ['distance_km']} km away — roughly {champ['travel_min']:.0f} min ride "
                   f"and only {champ['active_orders']} active order(s).")
        else:
            why = (f"Shortest realistic pickup ({champ['travel_min']:.0f} min ride, "
                   f"{champ['active_orders']} active orders, {champ['rating']}★) — "
                   f"active orders are weighted above distance because a loaded rider delays everyone.")

        return {
            "assigned": champ,
            "why": why,
            "candidates_considered": len(self.riders),
            "candidates_ranked": scored[:5],
            "hard_rejections": rejected[:4],
            "policy": {"rider_capacity": self.RIDER_CAPACITY,
                       "score_weights": {"travel_min": self.W_DISTANCE, "load": self.W_LOAD,
                                         "rating": self.W_RATING, "vehicle": self.W_VEHICLE}},
            "algorithm_note": note,
        }

    def simulate_tracking(self, assigned_rider: dict, travel_min: float, queue_min: float,
                          demand_index: float = 1.0, target_eta_min: float | None = None) -> dict:
        """Post-dispatch live view: queue time, ride, distance left, ETA band.

        The components are *scaled* so they sum to the ETA model's prediction
        whenever one is supplied.  Showing a 29-minute timeline next to a
        41-minute model ETA is the kind of contradiction that destroys trust in
        every other number on the screen, so the timeline is derived from, never
        computed in parallel with, the forecast.
        """
        wobble = 1.0 + 0.06 * (demand_index - 1.0)
        raw = {"queue": max(0.1, queue_min), "ride": max(0.1, travel_min * wobble), "handoff": 1.2}
        if target_eta_min:
            scale = float(target_eta_min) / sum(raw.values())
            parts = {k: v * scale for k, v in raw.items()}
        else:
            parts = dict(raw)
        queue_r, ride_r, hand_r = (round(parts["queue"], 1), round(parts["ride"], 1),
                                   round(parts["handoff"], 1))
        total = round(queue_r + ride_r + hand_r, 1)
        if target_eta_min:                      # absorb rounding drift on the ride leg
            ride_r = round(ride_r + (float(target_eta_min) - total), 1)
            total = round(queue_r + ride_r + hand_r, 1)
        return {
            "rider_id": assigned_rider["rider_id"],
            "rider_name": assigned_rider["name"],
            "rider_rating": assigned_rider["rating"],
            "vehicle": assigned_rider["vehicle"],
            "queue_min": queue_r,
            "ride_min": ride_r,
            "handoff_min": hand_r,
            "distance_left_km": assigned_rider["distance_km"],
            "eta_min": total,
            "traffic_level": None,   # filled by API layer
            "note": "queue + ride + handoff, scaled to the ETA model's prediction so the "
                    "screen never shows two conflicting totals",
            "matches_model_eta": (abs(total - float(target_eta_min)) <= 0.15
                                  if target_eta_min else None),
        }
