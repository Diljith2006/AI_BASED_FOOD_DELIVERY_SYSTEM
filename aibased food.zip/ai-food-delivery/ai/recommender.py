"""
ai/recommender.py — Sprint 1 + Sprint 6: rating-aware recommender with
marketplace discovery
----------------------------------------------------------------------
Four signals, because each alone fails differently:

  1. CONTENT  — cosine similarity between the item's feature vector and the
     diner's taste vector.  Carries cold-start (new user, new item).
  2. COLLABORATIVE — item-item co-occurrence.  Two levels: within a basket AND
     across a customer's whole history, so affinity can cross restaurants
     (a biryani lover in R10 is a signal for R03's biryani too).
  3. RATING — the marketplace dimension requested for this sprint.  Rankings use
     the **Bayesian (credibility) rating**, not the headline star:

         shrunk = (v·R + m·C) / (v + m)        m = 50, C = city mean rating

     This is the single most important marketplace detail: a brand-new place
     with 15 reviews at 4.7★ is NOT better than an established 4.5★ with 4,200
     reviews, and a naive average would say it is.  Shrinkage pulls thin
     evidence toward the city average, so "suggest by rating" stops meaning
     "suggest whichever new restaurant got three 5-star reviews".
  4. POPULARITY — volume, which is a proxy for reliability/logistics quality.

   FINAL = 0.30·content + 0.22·collaborative + 0.34·rating + 0.14·popularity

DISCOVERY: a dedicated exploration layer, because pure exploitation never shows
a diner anything new (the classic bandit problem — and a real commercial problem
for a marketplace that must seed demand for newly onboarded restaurants).
`discover_restaurants()` returns places the diner has NOT ordered from, ranked by
credibility rating, with a deliberate boost for newly onboarded kitchens.
"""
from __future__ import annotations

import json, os
import numpy as np
import pandas as pd
from sklearn.preprocessing import MultiLabelBinarizer

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")

SHRINK_M = 50.0          # credibility prior strength, in "pseudo reviews"
NEW_RESTAURANT_MAX_REVIEWS = 150     # below this, a listing counts as new


def _load_market():
    with open(os.path.join(DATA, "menu.json"), encoding="utf-8") as f:
        return json.load(f)


class HybridRecommender:
    W_CONTENT, W_CF, W_RATING, W_PRIOR = 0.30, 0.22, 0.34, 0.14

    def __init__(self):
        market = _load_market()
        self.items = market["items"]
        self.restaurants = market["restaurants"]
        self.by_rest = {r["id"]: r for r in self.restaurants}
        self.by_id = {it["id"]: it for it in self.items}
        self.ids = [it["id"] for it in self.items]
        self.idx = {iid: k for k, iid in enumerate(self.ids)}
        self.city_mean_rating = float(np.mean([r["rating"] for r in self.restaurants]))
        self._build_content_matrix()
        self._build_cf_matrix()
        self._build_ratings()

    # ------------------------------------------------------------ credibility
    def shrunk_rating(self, rid: str) -> float:
        """Bayesian average: how good is this restaurant really, given how much
        evidence we actually have?  Used for EVERY ranking in the product."""
        r = self.by_rest[rid]
        v, R = float(r["rating_count"]), float(r["rating"])
        m, C = SHRINK_M, self.city_mean_rating
        return (v * R + m * C) / (v + m)

    def _build_ratings(self):
        raw = np.array([self.by_rest[i["restaurant_id"]]["rating"] for i in self.items])
        shrunk = np.array([self.shrunk_rating(i["restaurant_id"]) for i in self.items])
        item_r = np.array([i["rating"] for i in self.items])
        self.item_rating_signal = (0.45 * shrunk + 0.30 * item_r + 0.25 * raw) / 5.0
        rk = np.array([self.shrunk_rating(r["id"]) for r in self.restaurants])
        self.rest_rating_signal = {r["id"]: v / 5.0 for r, v in zip(self.restaurants, rk)}

    def restaurant_view(self, rid: str, customer_locality: str | None = None) -> dict:
        """Presentation-ready restaurant record with the credibility maths exposed."""
        r = self.by_rest[rid]
        shrunk = self.shrunk_rating(rid)
        eta_hint = round(r["prep_speed"] * 18 + r["distance_hint_km"] * 2.6 + 8, 1)
        return {
            **r,
            "eta_hint_min": eta_hint,
            "shrunk_rating": round(shrunk, 3),
            "rating_reliability": ("low — few reviews" if r["rating_count"] < NEW_RESTAURANT_MAX_REVIEWS
                                   else "medium" if r["rating_count"] < 500 else "high"),
            "is_new": bool(r["is_new"] or r["rating_count"] < NEW_RESTAURANT_MAX_REVIEWS),
            "menu_rank": int(sorted(self.restaurants, key=lambda x: -self.shrunk_rating(x["id"]))
                             .index(r) + 1),
        }

    # ------------------------------------------------------ content features
    def _build_content_matrix(self):
        rows, tags = [], []
        for it in self.items:
            tags.append(it["tags"] + [it["cuisine"], it["category"],
                                      "veg" if it["veg"] else "nonveg",
                                      f"spice{it['spice']}"])
        mlb = MultiLabelBinarizer()
        tag_mat = mlb.fit_transform(tags).astype(float)
        self.tag_names = list(mlb.classes_)
        num = np.array([[it["spice"] / 3.0,
                         (it["price"] - 40) / 300.0,
                         it["prep_time_min"] / 28.0,
                         it["rating"] / 5.0,
                         it["popular_base"]] for it in self.items])
        mat = np.hstack([tag_mat * 1.6, num * 1.2])
        self.content_mat = mat / (np.linalg.norm(mat, axis=1, keepdims=True) + 1e-9)
        self.item_tag_sets = [set(t) for t in tags]

    def user_vector(self, prefs: dict) -> np.ndarray:
        liked = set()
        for c in prefs.get("cuisines", []):
            liked.add(c)
        for t in prefs.get("tags", []):
            liked.add(t)
        if prefs.get("veg_only"):
            liked.add("veg")
        for s in range(0, int(prefs.get("max_spice", 3)) + 1):
            liked.add(f"spice{s}")
        if not liked:
            liked = {"Main", "South Indian"}
        v = np.zeros(len(self.tag_names))
        for t in liked:
            if t in self.tag_names:
                v[self.tag_names.index(t)] = 1.0
        v = v * 1.6
        num = np.array([int(prefs.get("max_spice", 2)) / 3.0,
                        (float(prefs.get("max_price", 300)) - 40) / 300.0,
                        0.5, 0.9, 0.7]) * 1.2
        vec = np.concatenate([v, num])
        return vec / (np.linalg.norm(vec) + 1e-9)

    # ------------------------------------------------- collaborative filter
    def _build_cf_matrix(self):
        path = os.path.join(DATA, "order_lines.csv")
        self.cf_available = os.path.exists(path)
        self.n_co = 0
        n = len(self.ids)
        if not self.cf_available:
            self.cf_mat = np.zeros((n, n))
            return
        df = pd.read_csv(path)
        co = np.zeros((n, n))

        # (1) within-basket co-occurrence — "ordered together"
        baskets = df.groupby("order_id")["item_id"].apply(lambda s: sorted(set(s)))
        for b in baskets:
            k = [self.idx[i] for i in b if i in self.idx]
            if len(k) > 1:
                ix, iy = np.meshgrid(k, k)
                np.add.at(co, (ix.ravel(), iy.ravel()), 1)
        self.n_co = int(len(baskets))

        # (2) customer-history co-occurrence — "this diner, across restaurants".
        #     This is what lets affinity cross restaurant boundaries: someone who
        #     keeps ordering biryani somewhere is a signal for biryani elsewhere.
        cust_items = df.groupby("customer_id")["item_id"].apply(lambda s: sorted(set(s)))
        for seq in cust_items:
            k = [self.idx[i] for i in seq if i in self.idx]
            if len(k) > 1:
                ix, iy = np.meshgrid(k, k)
                np.add.at(co, (ix.ravel(), iy.ravel()), 0.5)
        self.n_customers = int(len(cust_items))
        np.fill_diagonal(co, 0)

        norm = np.linalg.norm(co, axis=1, keepdims=True)
        self.cf_mat = co / (norm + 1e-9)

    # -------------------------------------------------------------- ranking
    def recommend(self, prefs: dict | None = None, cart_ids: list[str] | None = None,
                  n: int = 6, exclude: list[str] | None = None,
                  tried_restaurants: list[str] | None = None,
                  include_exploration: bool = True) -> dict:
        prefs = prefs or {}
        cart_ids = [c for c in (cart_ids or []) if c in self.by_id]
        exclude = set(exclude or [])
        tried = set(tried_restaurants or [])
        uvec = self.user_vector(prefs)

        content = self.content_mat @ uvec

        if cart_ids:
            cf = np.mean([self.cf_mat[self.idx[c]] for c in cart_ids], axis=0)
        else:
            cf = np.zeros(len(self.ids))
        cf = cf / (cf.max() + 1e-9) if cf.max() > 0 else cf

        prior = np.array([(it["popular_base"] * 0.7 + it["rating"] / 5.0 * 0.3) for it in self.items])
        prior = (prior - prior.min()) / (prior.max() - prior.min() + 1e-9)

        rating = self.item_rating_signal

        final = (self.W_CONTENT * content + self.W_CF * cf
                 + self.W_RATING * rating + self.W_PRIOR * prior)

        max_price = prefs.get("max_price")
        max_spice = prefs.get("max_spice")
        veg_only = prefs.get("veg_only")
        cuisines = set(prefs.get("cuisines") or [])
        only_new_restaurants = bool(prefs.get("only_new_restaurants"))
        max_restaurant_distance = prefs.get("max_distance_km")
        rest_filter = prefs.get("restaurant_ids")

        out = []
        for k, iid in enumerate(self.ids):
            it = self.by_id[iid]
            rid = it["restaurant_id"]
            rest = self.by_rest[rid]
            if iid in exclude or iid in cart_ids:
                continue
            if veg_only and not it["veg"]:
                continue
            if max_price and it["price"] > float(max_price):
                continue
            if max_spice is not None and it["spice"] > int(max_spice):
                continue
            if cuisines and it["cuisine"] not in cuisines:
                continue
            if only_new_restaurants and not rest["is_new"]:
                continue
            if rest_filter and rid not in rest_filter:
                continue
            if max_restaurant_distance and rest["distance_hint_km"] > float(max_restaurant_distance):
                continue

            # reasons are ordered most-diner-specific first: a generic "highly
            # rated" on every card tells the diner nothing and reads as filler.
            reasons = []
            if content[k] > 0.55:
                hit = sorted(self.item_tag_sets[k] & set(list(cuisines) + list(prefs.get("tags") or []) +
                                                        (["veg"] if veg_only else [])))
                reasons.append("matches your taste" + (f" ({', '.join(hit[:3])})" if hit else ""))
            if cart_ids and cf[k] > 0.25:
                top = cart_ids[int(np.argmax([self.cf_mat[self.idx[c]][k] for c in cart_ids]))]
                reasons.append(f"often ordered with {self.by_id[top]['name']}")
            if rid not in tried and rid not in {self.by_id[c]["restaurant_id"] for c in cart_ids}:
                reasons.append(f"new to you — you haven't ordered from {rest['name']}")
            if rating[k] > 0.86:
                reasons.append(f"credibility rating {self.shrunk_rating(rid):.2f} from "
                               f"{rest['rating_count']} reviews")
            if not reasons:
                reasons.append(f"solid choice from {rest['name']}")

            out.append({
                "item": it,
                "restaurant": self.restaurant_view(rid),
                "score": round(float(final[k]), 4),
                "breakdown": {"content": round(float(content[k]), 3),
                              "collaborative": round(float(cf[k]), 3),
                              "rating": round(float(rating[k]), 3),
                              "popularity": round(float(prior[k]), 3)},
                "reason": reasons[0],
                "reasons": reasons,
            })
        out.sort(key=lambda d: (-d["score"], d["item"]["price"]))
        top = out[:n]

        # ---------------- exploration slot ---------------------------------
        # Reserve one slot for a restaurant the diner has not tried.  Without
        # this, a pure-argmax recommender can never surface a new kitchen, and
        # new kitchens never accumulate the orders they need to earn a rating.
        exploration = None
        if include_exploration and tried:
            best_new = [c for c in out
                        if c["item"]["restaurant_id"] not in tried
                        and c["item"]["restaurant_id"] not in {self.by_id[x]["restaurant_id"] for x in cart_ids}]
            if best_new:
                newish = [c for c in best_new if c["restaurant"]["is_new"]] or best_new
                pick = max(newish, key=lambda c: (self.rest_rating_signal[c["item"]["restaurant_id"]],
                                                  c["score"]))
                pick = dict(pick)
                pick["reason"] = (f"try something new — {pick['restaurant']['name']} "
                                  f"({pick['restaurant']['rating']}★ from "
                                  f"{pick['restaurant']['rating_count']} ratings)")
                pick["exploration"] = True
                exploration = pick
                if pick["item"]["id"] not in {c["item"]["id"] for c in top}:
                    top = top[:max(0, n - 1)] + [pick]

        return {
            "recommendations": top,
            "exploration_slot": exploration,
            "model": "hybrid: content + item-item CF (basket & customer history) + credibility rating + popularity",
            "weights": {"content": self.W_CONTENT, "collaborative": self.W_CF,
                        "rating": self.W_RATING, "popularity": self.W_PRIOR},
            "rating_method": f"Bayesian shrinkage, m={SHRINK_M:.0f} pseudo-reviews, city mean "
                             f"{self.city_mean_rating:.2f}★",
            "cf_baskets_seen": self.n_co,
            "cold_start": not bool(cart_ids),
        }

    # ------------------------------------------------- restaurant discovery
    def discover_restaurants(self, prefs: dict | None = None, tried_restaurants: list[str] | None = None,
                             sort: str = "best_match", n: int = 6,
                             exclude_tried: bool | None = None) -> dict:
        """Restaurant-level suggestions — the marketplace surface.

        sort: best_match | top_rated | new | fastest | cheapest

        exclude_tried: hide kitchens the diner has already used.  Defaults to
        True only for the `new` sort (a "discover something new" tab that shows
        your regular place is useless); best_match and top_rated stay inclusive,
        because ranking the city's best restaurants should not hide the one the
        diner already loves.
        """
        prefs = prefs or {}
        tried = set(tried_restaurants or [])
        if exclude_tried is None:
            exclude_tried = (sort == "new")
        cuisines = set(prefs.get("cuisines") or [])
        veg_only = bool(prefs.get("veg_only"))
        max_price = prefs.get("max_price")

        rows = []
        for r in self.restaurants:
            rid = r["id"]
            shrunk = self.shrunk_rating(rid)
            serves = {i["cuisine"] for i in self.items if i["restaurant_id"] == rid}
            price_ok = True
            if max_price:
                cheapest = min((i["price"] for i in self.items if i["restaurant_id"] == rid), default=0)
                price_ok = cheapest <= float(max_price)
            veg_ok = True
            if veg_only:
                veg_ok = any(i["veg"] for i in self.items if i["restaurant_id"] == rid)
            if not (price_ok and veg_ok):
                continue
            if exclude_tried and rid in tried:
                continue

            cuisine_match = 1.0 if (cuisines & serves) else 0.0
            tried_before = rid in tried
            new_listing = bool(r["is_new"])
            # best_match blends credibility, taste fit, novelty and speed
            # Deliberately modest novelty weight.  An earlier version gave new
            # listings a 0.18 boost and they swamped the main ranking — which
            # would mean a marketplace that pushes unproven kitchens at every
            # diner.  Discovery gets its own budget (exploration slot + the
            # "new & noteworthy" row) instead of hijacking the default sort.
            match = (0.60 * (shrunk / 5.0)          # quality leads, always
                     + 0.24 * cuisine_match
                     + 0.10 * (1.0 - min(1.0, r["prep_speed"] - 0.7))
                     + 0.06 * (0.0 if tried_before else 1.0))
            why = []
            if shrunk >= max(x["shrunk_rating"] for x in [self.restaurant_view(y["id"]) for y in self.restaurants]) - 0.01:
                why.append("best credibility rating in the city right now")
            if cuisine_match:
                why.append(f"cooks {', '.join(sorted(cuisines & serves))} — your usual")
            if new_listing:
                why.append(f"newly onboarded ({r['rating_count']} ratings so far)")
            if not tried_before:
                why.append("you haven't ordered from here")
            if not why:
                why.append(f"reliable {r['cuisine']} kitchen, {r['rating']}★")

            rows.append({
                "restaurant": self.restaurant_view(rid),
                "match_score": round(float(match), 4),
                "shrunk_rating": round(shrunk, 3),
                "cuisine_match": bool(cuisine_match),
                "tried_before": tried_before,
                "is_new": new_listing,
                "why": why[0],
                "reasons": why,
                "distance_hint_km": r["distance_hint_km"],
            })

        orders = {
            "best_match": lambda d: (-d["match_score"], -d["shrunk_rating"]),
            "top_rated": lambda d: (-d["shrunk_rating"], -d["restaurant"]["rating_count"]),
            "new": lambda d: (not d["is_new"], -d["shrunk_rating"]),
            "fastest": lambda d: (d["restaurant"]["eta_hint_min"], -d["shrunk_rating"]),
            "cheapest": lambda d: (d["restaurant"]["cost_for_two"], -d["shrunk_rating"]),
        }
        rows.sort(key=orders.get(sort, orders["best_match"]))

        # "new & noteworthy" is a *separate* list on purpose: mixing exploration
        # into the main ranking hides it, and burying it at the bottom hides it too.
        new_rows = sorted([r for r in rows if r["is_new"]],
                          key=lambda d: -d["shrunk_rating"])[:3]
        return {
            "sort": sort,
            "restaurants": rows[:n],
            "all_count": len(rows),
            "new_and_noteworthy": new_rows,
            "rating_method": f"credibility rating = (v·R + {SHRINK_M:.0f}·{self.city_mean_rating:.2f}) / (v + {SHRINK_M:.0f})",
            "note": "ranked by credibility rating, not the raw star average — a 4.9★ from 38 ratings "
                    "is not evidence of quality yet",
            "tried_restaurants": sorted(tried),
        }
