"""
ai/forecast.py — Sprint 4 deliverable: demand forecasting + kitchen prep plan
----------------------------------------------------------------------------
Two layers:

  LAYER 1  Total order volume.  Ridge regression on calendar + weather features:
           trend index, weekday one-hot, cyclical hour encoding, weekend flag.
           A linear model is used *on purpose*: with only 90 days of history a
           flexible model overfits, and linear calendars are easy to defend.

  LAYER 2  Item mix.  P(top item | hour, weekday) estimated from the last 14
           days of line items, so the forecast split adapts to what is actually
           selling this fortnight rather than a stale global average.

Backtest: the final 7 days are held out and the model is scored against a
seasonal-naive baseline ("next Tuesday 1pm = last Tuesday 1pm"), which is the
real benchmark — beating a fixed mean proves nothing.
"""
from __future__ import annotations

import json, os
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")


def _cyclic(v, period):
    return np.sin(2 * np.pi * v / period), np.cos(2 * np.pi * v / period)


class DemandForecaster:
    def __init__(self):
        self.orders = pd.read_csv(os.path.join(DATA, "orders.csv"), parse_dates=["timestamp"])
        self.lines = pd.read_csv(os.path.join(DATA, "order_lines.csv"), parse_dates=["timestamp"])
        with open(os.path.join(DATA, "menu.json"), encoding="utf-8") as f:
            self.menu = json.load(f)["items"]
        self.by_id = {i["id"]: i for i in self.menu}
        self.model = None
        self.metrics: dict = {}
        self.hourly = (self.orders.groupby([self.orders.timestamp.dt.date, "hour"])
                       .size().rename("n").reset_index()
                       .rename(columns={"timestamp": "date"}))
        self.hourly["date"] = pd.to_datetime(self.hourly["date"])

    # ---------------------------------------------------------------- design
    @staticmethod
    def _design(dates: pd.Series, hours: np.ndarray) -> pd.DataFrame:
        """Feature design.
        Learning log: the first version encoded hour-of-day as sin/cos.  That
        cost us: sine waves are unimodal, but demand has TWO peaks (lunch and
        dinner), so the model flattened the peaks and lost to the seasonal-naive
        baseline.  Hour-of-day is therefore one-hot encoded, which lets the
        model learn any shape, while day-of-week keeps the cyclical terms plus
        dummies.  Lesson: cyclical encoding is for *periodic smooth* signals,
        not for signals with sharp structure inside the period.
        """
        dayidx = (dates - pd.Timestamp("2026-01-01")).dt.days.to_numpy(dtype=float)
        dow = dates.dt.weekday.to_numpy()
        hours = np.asarray(hours).astype(int)
        X = {"trend": dayidx / 90.0, "is_weekend": (dow >= 5).astype(float)}
        for k in range(24):                      # hour-of-day one-hot
            X[f"hour_{k}"] = (hours == k).astype(float)
        ds, dc = _cyclic(dow.astype(float), 7)
        X["dow_sin"], X["dow_cos"] = ds, dc
        for k in range(1, 7):                    # day-of-week one-hot
            X[f"dow_{k}"] = (dow == k).astype(float)
        for k in (12, 13, 19, 20, 21):           # weekend meal-peak interactions
            X[f"we_x_hour{k}"] = ((dow >= 5) & (hours == k)).astype(float)
        return pd.DataFrame(X)

    def train(self, holdout_days: int = 7) -> dict:
        h = self.hourly.copy()
        cutoff = h["date"].max() - pd.Timedelta(days=holdout_days - 1)
        tr, te = h[h["date"] < cutoff], h[h["date"] >= cutoff]
        Xtr, Xte = self._design(tr["date"], tr["hour"].to_numpy()), self._design(te["date"], te["hour"].to_numpy())
        self.feature_names = list(Xtr.columns)
        m = Ridge(alpha=1.0).fit(Xtr, tr["n"].to_numpy())

        pred_te = np.clip(m.predict(Xte), 0, None)
        # seasonal-naive baseline: same hour, same weekday, 7 days earlier
        prev = h.copy()
        prev["next_date"] = prev["date"] + pd.Timedelta(days=7)
        naive = te.merge(prev[["next_date", "hour", "n"]], left_on=["date", "hour"],
                         right_on=["next_date", "hour"], how="left", suffixes=("", "_prev"))
        naive_vals = naive["n_prev"].fillna(h["n"].mean()).to_numpy()

        # raw MAPE is dominated by 03:00-05:00 buckets where the true count is
        # ~0-1 orders; the number a kitchen manager cares about is accuracy in
        # the service windows (10:00-15:00 and 18:00-22:00), so we report both.
        peak_mask = te["hour"].isin([10, 11, 12, 13, 14, 18, 19, 20, 21, 22]).to_numpy()

        def wape(y, p, mask=None):
            y, p = np.asarray(y, float), np.asarray(p, float)
            if mask is not None:
                y, p = y[mask], p[mask]
            return round(float(np.sum(np.abs(y - p)) / max(1e-9, np.sum(y)) * 100), 1)

        self.metrics = {
            "holdout_days": holdout_days,
            "holdout_points": int(len(te)),
            "ML_Ridge": {
                "MAE_orders_per_hour": round(float(mean_absolute_error(te["n"], pred_te)), 2),
                "WAPE_pct_all_hours": wape(te["n"], pred_te),
                "WAPE_pct_service_windows": wape(te["n"], pred_te, peak_mask),
                "MAPE_pct_all_hours": round(float(np.mean(np.abs((te["n"] - pred_te) / np.maximum(te["n"], 1))) * 100), 1),
            },
            "baseline_seasonal_naive": {
                "MAE_orders_per_hour": round(float(mean_absolute_error(te["n"], naive_vals)), 2),
                "WAPE_pct_all_hours": wape(te["n"], naive_vals),
                "WAPE_pct_service_windows": wape(te["n"], naive_vals, peak_mask),
                "MAPE_pct_all_hours": round(float(np.mean(np.abs((te["n"] - naive_vals) / np.maximum(te["n"], 1))) * 100), 1),
            },
        }
        self.metrics["MAE_improvement_vs_naive_pct"] = round(
            100 * (1 - self.metrics["ML_Ridge"]["MAE_orders_per_hour"] /
                   max(1e-9, self.metrics["baseline_seasonal_naive"]["MAE_orders_per_hour"])), 1)

        self.model = Ridge(alpha=1.0).fit(self._design(h["date"], h["hour"].to_numpy()), h["n"].to_numpy())
        self._build_item_mix()
        self.last_date = h["date"].max()
        return self.metrics

    def _build_item_mix(self):
        recent = self.lines[self.lines.timestamp >= self.lines.timestamp.max() - pd.Timedelta(days=14)]
        mix = recent.groupby(["hour", "item_id"]).size().rename("n").reset_index()
        tot = mix.groupby("hour")["n"].transform("sum")
        mix["share"] = mix["n"] / tot
        self.item_mix = {(int(r.hour), r.item_id): float(r.share) for r in mix.itertuples()}

        # restaurant mix per hour: which kitchen carries the load at 20:00?
        # Without this the "prep list" would tell one kitchen to cook every
        # restaurant's dishes, which is useless in a marketplace.
        rmix = recent.groupby(["hour", "restaurant_id"]).size().rename("n").reset_index()
        rtot = rmix.groupby("hour")["n"].transform("sum")
        rmix["share"] = rmix["n"] / rtot
        self.rest_mix = {(int(r.hour), r.restaurant_id): float(r.share) for r in rmix.itertuples()}
        self.rest_hour_orders = {(int(r.hour), r.restaurant_id): float(r.n) for r in rmix.itertuples()}

        # Within-restaurant item mix: "of the orders THIS kitchen got at 20:00,
        # what share was biryani?"  Using the citywide share here (as a first cut
        # did) under-counts every dish, because an item's citywide share is tiny
        # once 15 restaurants × 6 dishes are in the denominator.
        rim = recent.groupby(["hour", "restaurant_id", "item_id"]).size().rename("n").reset_index()
        rtot2 = rim.groupby(["hour", "restaurant_id"])["n"].transform("sum")
        rim["share"] = rim["n"] / rtot2
        self.rest_item_mix = {(int(r.hour), r.restaurant_id, r.item_id): float(r.share)
                              for r in rim.itertuples()}
        self.item_lines_per_order = float(len(recent) / max(1, recent["order_id"].nunique()))

    # -------------------------------------------------------------- forecast
    def next_day(self, day_offset: int = 1, weather: int | None = None) -> dict:
        if self.model is None:
            self.train()
        target = pd.Timestamp(self.last_date) + pd.Timedelta(days=day_offset)
        full_dates = pd.Series([target] * 24)
        hours = np.arange(24)
        X = self._design(full_dates, hours)
        base = np.clip(self.model.predict(X), 0, None)

        if weather == 2:
            base = base * np.array([1.0 + 0.10 if 11 <= h <= 22 else 1.0 for h in hours])
        elif weather == 1:
            base = base * 1.03

        forecast = [{"hour": int(h), "orders": int(round(base[h])), "order_label": f"{h:02d}:00"}
                    for h in hours]
        peak = max(forecast, key=lambda d: d["orders"])
        total = int(sum(f["orders"] for f in forecast))

        # per-restaurant prep list for the busiest hours (kitchen actionability).
        # A marketplace forecast is only useful if it says WHICH kitchen must
        # cook WHAT, so each hour is exploded into restaurant-level work lists.
        busy = sorted(forecast, key=lambda d: -d["orders"])[:3]
        prep = []
        for b in busy:
            hour = b["hour"]
            rests = sorted([(rid, sh) for (hh, rid), sh in getattr(self, "rest_mix", {}).items() if hh == hour],
                           key=lambda t: -t[1])[:3]
            for rid, rshare in rests:
                items = [(iid, sh) for (hh, rr, iid), sh in getattr(self, "rest_item_mix", {}).items()
                         if hh == hour and rr == rid]
                items.sort(key=lambda t: -t[1])
                r_orders = b["orders"] * rshare
                for iid, share in items[:2]:
                    units = max(1, int(round(r_orders * self.item_lines_per_order * share)))
                    prep.append({
                        "hour": hour, "restaurant_id": rid,
                        "restaurant_name": self.by_id[iid]["restaurant_name"],
                        "expected_orders": int(round(r_orders)),
                        "item_id": iid, "item_name": self.by_id[iid]["name"],
                        "expected_units": units,
                    })
        return {
            "target_date": str(target.date()),
            "weekday": target.day_name(),
            "total_orders": total,
            "peak_hour": peak["hour"], "peak_orders": peak["orders"],
            "hourly": forecast,
            "kitchen_prep_list": prep,
            "model": "Ridge on calendar/cyclical features + 14-day item mix",
            "metrics": self.metrics,
        }

    def demand_index(self, hour: int, day_offset: int = 0) -> float:
        """0..1+ live pressure used by the pricing engine (1.0 == average hour)."""
        fc = self.next_day(day_offset)
        val = next(f["orders"] for f in fc["hourly"] if f["hour"] == int(hour))
        avg = max(1.0, fc["total_orders"] / 24.0)
        return round(val / avg, 3)
