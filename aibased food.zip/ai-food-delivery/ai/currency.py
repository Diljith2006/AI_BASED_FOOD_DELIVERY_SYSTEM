"""
ai/currency.py — Indian Rupee formatting + amount in words
----------------------------------------------------------
Why this module exists rather than a one-line f-string: India does not use the
western 3-digit grouping.  The rupee uses the **lakh/crore** convention —
the last three digits, then groups of two:

    western : ₹ 1,234,567.50
    Indian  : ₹ 12,34,567.50        <- what a diner in Coimbatore expects

Every money value in the product (menu, cart, invoice, metrics, chatbot replies)
is rendered through `inr()` so a price never appears in two different shapes.
Amounts are also spelled out in words, which is how Indian bills, invoices and
receipts print the total.
"""
from __future__ import annotations

CURRENCY = {
    "code": "INR",
    "symbol": "₹",
    "name": "Indian Rupee",
    "short": "Rupee",
    "grouping": "indian (last 3 digits, then groups of 2 — lakh/crore)",
    "subunit": "paise",
    "sample": "₹12,34,567.50",
}

_ONES = ["", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten",
         "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen",
         "eighteen", "nineteen"]
_TENS = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"]


def _two_digits(n: int) -> str:
    if n < 20:
        return _ONES[n]
    return (_TENS[n // 10] + ("-" + _ONES[n % 10] if n % 10 else "")).strip()


def _indian_words(n: int) -> str:
    """Indian numbering system: crore / lakh / thousand / hundred."""
    if n == 0:
        return "zero"
    parts = []
    for divisor, label in ((10_000_000, "crore"), (100_000, "lakh"), (1_000, "thousand")):
        if n >= divisor:
            parts.append(f"{_indian_words(n // divisor)} {label}")
            n %= divisor
    if n >= 100:
        parts.append(f"{_ONES[n // 100]} hundred")
        n %= 100
    if n:
        parts.append(_two_digits(n))
    return " ".join(parts)


def inr(amount: float, decimals: int | None = None, symbol: bool = True) -> str:
    """Format a number as Indian Rupees with lakh/crore digit grouping.

    inr(1234567.5) -> '₹12,34,567.50'
    inr(646)       -> '₹646'
    inr(-60)       -> '-₹60'
    """
    neg = amount < 0
    amount = abs(float(amount))
    if decimals is None:
        decimals = 2 if round(amount, 2) % 1 else 0
    whole = int(amount)
    frac = amount - whole

    s = str(whole)
    if len(s) > 3:                                   # Indian grouping kicks in
        head, tail = s[:-3], s[-3:]
        chunks = []
        while len(head) > 2:
            chunks.insert(0, head[-2:])
            head = head[:-2]
        if head:
            chunks.insert(0, head)
        s = ",".join(chunks + [tail])

    out = s
    if decimals:
        frac_str = f"{frac:.{decimals}f}"[1:]         # '.50'
        out += frac_str
    return ("-" if neg else "") + (CURRENCY["symbol"] if symbol else "") + out


def inr_words(amount: float, decimals: int | None = None) -> str:
    """Amount spelled out the way an Indian bill prints it, e.g.
    'six hundred forty-six rupees and fifty paise only'."""
    neg = amount < 0
    amount = abs(float(amount))
    whole = int(amount)
    # round to the requested precision BEFORE splitting, so "199.999" reads
    # "two hundred rupees only" and never "one hundred ninety-nine rupees and
    # one hundred paise" — the classic rounding bug in bill printers.
    if decimals is None:
        rounded = round(amount, 2)
        whole = int(rounded)
        paise = int(round((rounded - whole) * 100))
    else:
        rounded = round(amount, decimals)
        whole = int(rounded)
        paise = int(round((rounded - whole) * 100))
    if paise == 100:
        whole, paise = whole + 1, 0

    words = f"{_indian_words(whole)} rupee" + ("" if whole == 1 else "s")
    if paise:
        words += f" and {_indian_words(paise)} paise"
    return ("minus " if neg else "") + words + " only"


def currency_meta() -> dict:
    """Exposed on /api/currency so the UI can prove which currency it renders."""
    return {
        **CURRENCY,
        "examples": [inr(90), inr(646), inr(1234.5), inr(1234567.5)],
        "in_words": inr_words(646.5),
    }


if __name__ == "__main__":      # quick self-check
    checks = [(45, "₹45"), (646, "₹646"), (1234.5, "₹1,234.50"), (1234567.5, "₹12,34,567.50"),
              (99999, "₹99,999"), (100000, "₹1,00,000"), (10000000, "₹1,00,00,000"),
              (-60, "-₹60")]
    for value, expected in checks:
        got = inr(value)
        assert got == expected, f"inr({value}) -> {got}, expected {expected}"
    assert inr_words(646.5) == "six hundred forty-six rupees and fifty paise only", inr_words(646.5)
    assert inr_words(100000) == "one lakh rupees only", inr_words(100000)
    assert inr_words(200.999) == "two hundred one rupees only", inr_words(200.999)
    print("currency self-check passed")
    print("  " + " | ".join(inr(v) for v in [45, 90, 646, 1234.5, 99999, 100000, 1234567.5]))
    print("  " + inr_words(646.5))
