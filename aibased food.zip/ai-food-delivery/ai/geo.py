"""
ai/geo.py — Coimbatore localities and distance maths
----------------------------------------------------
Restaurants and customers both live at real Coimbatore localities, so every
distance in the system (ETA features, delivery fee tiers, dispatch scoring) can
be derived from one shared source instead of three unrelated random numbers.
"""
from __future__ import annotations

import math

# approximate locality centroids (lat, lng)
LOCALITIES: dict[str, tuple[float, float]] = {
    "R.S. Puram":      (10.9978, 76.9510),
    "Peelamedu":       (11.0280, 76.9630),
    "Saibaba Colony":  (11.0185, 76.9380),
    "Gandhipuram":     (11.0170, 76.9674),
    "Vadavalli":       (11.0270, 76.8880),
    "Singanallur":     (10.9930, 77.0030),
    "Race Course":     (11.0040, 76.9720),
    "Thudiyalangulam": (11.0500, 76.9600),
    "Kuniamuthur":     (10.9600, 76.9500),
    "Saravanampatti":  (11.0650, 77.0000),
    "Ganapathy":       (11.0300, 76.9800),
}
CITY_CENTRE = (11.0168, 76.9558)

# a road network is never a straight line
ROAD_FACTOR = 1.35


def haversine_km(a: tuple[float, float], b: tuple[float, float]) -> float:
    """Great-circle distance in km between two (lat, lng) pairs."""
    R = 6371.0
    p1, p2 = math.radians(a[0]), math.radians(b[0])
    dp = p2 - p1
    dl = math.radians(b[1] - a[1])
    h = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * R * math.asin(math.sqrt(h))


def road_km(a: tuple[float, float], b: tuple[float, float]) -> float:
    """Driving-ish distance: great-circle inflated by a road factor."""
    return haversine_km(a, b) * ROAD_FACTOR


def locality_coords(name: str) -> tuple[float, float]:
    return LOCALITIES.get(name, CITY_CENTRE)


def jitter(coords: tuple[float, float], km: float = 0.6, seed: int | None = None) -> tuple[float, float]:
    """Nudge a locality centroid so not every address lands on the same point."""
    import random
    rng = random.Random(seed)
    d_lat = rng.uniform(-km, km) / 111.0
    d_lng = rng.uniform(-km, km) / (111.0 * math.cos(math.radians(coords[0])))
    return (round(coords[0] + d_lat, 5), round(coords[1] + d_lng, 5))
