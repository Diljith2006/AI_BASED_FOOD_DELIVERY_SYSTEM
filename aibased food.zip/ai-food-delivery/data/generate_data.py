"""
generate_data.py
----------------
Creates the synthetic (but realistically shaped) dataset used to train and
validate the AI modules of Sizzle.AI.

The marketplace is now MULTI-RESTAURANT, so the generator changed in three ways:
  1. every order is placed with ONE restaurant (as in a real marketplace),
     chosen by rating credibility × cuisine fit × open hours;
  2. items are drawn from that restaurant's own menu only;
  3. distance is no longer random — it is the real road distance between the
     customer's locality and the restaurant's location (ai/geo.py).

Why synthetic?  A live food-delivery dataset is proprietary, so we simulate an
order stream whose *generative process* is known.  That gives us a labelled
ground truth for the ETA model (we can prove the model recovered the physics)
while still producing messy, noisy, real-looking data.

Outputs
  data/orders.csv        one row per order  (ETA regression + pricing)
  data/order_lines.csv   one row per line item (collaborative filtering + forecasting)
  data/customers.csv     customer preference profiles (recommender cold-start)
  data/riders.json       rider fleet snapshot (dispatch / smart routing)

Run:  python data/generate_data.py       (deterministic, seed = 42)
"""
from __future__ import annotations
import json, math, os, random
from datetime import datetime, timedelta

import numpy as np
import pandas as pd

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ai.geo import LOCALITIES, jitter, road_km   # noqa: E402

SEED = 42
random.seed(SEED)
np.random.seed(SEED)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")

N_DAYS = 90
END_DATE = datetime(2026, 10, 6)          # data ends "yesterday"
N_CUSTOMERS = 320
TARGET_ORDERS = 42000

# ---------------------------------------------------------------- menu load
with open(os.path.join(DATA, "menu.json"), encoding="utf-8") as f:
    MARKET = json.load(f)
ITEMS = {it["id"]: it for it in MARKET["items"]}
ITEM_IDS = list(ITEMS)
RESTAURANTS = {r["id"]: r for r in MARKET["restaurants"]}
MENU = {"items": MARKET["items"], "restaurants": MARKET["restaurants"]}

# items grouped per restaurant, for restaurant-scoped basket drawing
BY_RESTAURANT: dict[str, list[dict]] = {}
for _it in MARKET["items"]:
    BY_RESTAURANT.setdefault(_it["restaurant_id"], []).append(_it)

# restaurant -> {cuisines it serves}
BY_RESTAURANT_TAGS: dict[str, set] = {}
for _it in MARKET["items"]:
    BY_RESTAURANT_TAGS.setdefault(_it["restaurant_id"], set()).add(_it["cuisine"])

# credibility of a rating: the same Bayesian shrinkage the recommender uses, so
# the DEMAND simulator and the RECOMMENDER agree on what "well rated" means.
CITY_MEAN_RATING = float(np.mean([r["rating"] for r in MARKET["restaurants"]]))
SHRINK_M = 50.0


def shrunk_rating(r: dict) -> float:
    v, R = float(r["rating_count"]), float(r["rating"])
    return (v * R + SHRINK_M * CITY_MEAN_RATING) / (v + SHRINK_M)

# --------------------------------------------------- demand shape over a day
# Relative order probability per hour: two meal peaks + a late-night shawarma tail.
HOUR_SHAPE = {
    0: 0.10, 1: 0.06, 2: 0.03, 3: 0.01, 4: 0.01, 5: 0.02, 6: 0.15, 7: 0.55,
    8: 0.95, 9: 0.80, 10: 0.55, 11: 0.85, 12: 2.60, 13: 2.30, 14: 0.90,
    15: 0.45, 16: 0.55, 17: 0.80, 18: 1.35, 19: 2.35, 20: 2.85, 21: 2.20,
    22: 1.30, 23: 0.55,
}
WEEKDAY_MULT = {0: 0.92, 1: 0.90, 2: 0.94, 3: 1.00, 4: 1.14, 5: 1.28, 6: 1.18}  # Mon..Sun

# Which categories sell in which part of day (drives item-hour affinity).
CATEGORY_DAYPART = {
    "Breakfast":  {"morning": 3.2, "lunch": 0.5, "evening": 0.2, "night": 0.05},
    "Main":       {"morning": 0.2, "lunch": 1.6, "evening": 1.4, "night": 0.9},
    "Starter":    {"morning": 0.1, "lunch": 0.7, "evening": 1.5, "night": 1.2},
    "Bread":      {"morning": 0.1, "lunch": 1.0, "evening": 1.2, "night": 0.8},
    "Chinese":    {"morning": 0.1, "lunch": 0.9, "evening": 1.4, "night": 1.1},
    "Fast Food":  {"morning": 0.3, "lunch": 0.8, "evening": 1.2, "night": 1.7},
    "Dessert":    {"morning": 0.2, "lunch": 0.6, "evening": 1.0, "night": 1.3},
    "Beverage":   {"morning": 1.5, "lunch": 0.7, "evening": 1.3, "night": 0.7},
}


def daypart(h: int) -> str:
    if 6 <= h < 11:
        return "morning"
    if 11 <= h < 16:
        return "lunch"
    if 16 <= h < 19:
        return "evening"
    return "night"


def traffic_level(h: int, dow: int) -> int:
    """1 = free flow, 2 = moderate, 3 = heavy. Follows the two rush windows."""
    base = 1
    if h in (8, 9, 17, 18, 22):
        base = 2
    if h in (12, 13, 19, 20, 21):
        base = 3
    if dow >= 4 and base < 3:                      # Fri/Sat/Sun nudge
        base += 1
    return min(3, base)


def weather_for(d: datetime) -> int:
    """0 clear, 1 cloudy, 2 rain.  October = NE-monsoon onset in Tamil Nadu."""
    p_rain = 0.30 if d.month in (10, 11) else 0.10
    r = random.random()
    return 2 if r < p_rain else (1 if r < p_rain + 0.25 else 0)


# ------------------------------------------------------------------ customers
CUISINE_POOL = ["South Indian", "North Indian", "Chinese", "Arabian", "Fast Food", "Dessert", "Beverage"]
CITY = ["R.S. Puram", "Peelamedu", "Saibaba Colony", "Gandhipuram", "Vadavalli",
        "Singanallur", "Race Course", "Thudiyalangulam", "Kuniamuthur", "Saravanampatti"]

customers = []
for c in range(1, N_CUSTOMERS + 1):
    prefs = random.sample(CUISINE_POOL, k=random.choice([1, 2, 2, 3]))
    loc = random.choice(CITY)
    lat, lng = jitter(LOCALITIES[loc], km=0.7, seed=1000 + c)
    tried = random.sample(list(RESTAURANTS), k=random.choice([2, 3, 3, 4, 5]))
    customers.append({
        "customer_id": f"C{c:04d}",
        "name": f"Customer {c:04d}",
        "locality": loc, "lat": lat, "lng": lng,
        "restaurants_tried": "|".join(sorted(tried)),
        "pref_cuisines": "|".join(prefs),
        "veg_only": int(random.random() < 0.34),
        "max_spice": random.choice([1, 2, 2, 3, 3]),
        "budget_band": random.choice(["low", "mid", "mid", "high"]),
        "orders_placed": 0,
    })
cust_df = pd.DataFrame(customers)
cust_df.to_csv(os.path.join(DATA, "customers.csv"), index=False)

# ------------------------------------------------------------- firing orders
rows, lines = [], []
order_seq = 0
day_weights = [1.0 + 0.30 * (i / N_DAYS) for i in range(N_DAYS)]   # gentle growth trend

for day_i in range(N_DAYS):
    d = END_DATE - timedelta(days=N_DAYS - 1 - day_i)
    dow = d.weekday()
    n_orders = int(TARGET_ORDERS / N_DAYS * day_weights[day_i] *
                   WEEKDAY_MULT[dow] * np.random.normal(1.0, 0.08))
    hours = list(HOUR_SHAPE)
    probs = np.array([HOUR_SHAPE[h] for h in hours], dtype=float)
    probs /= probs.sum()

    for _ in range(max(5, n_orders)):
        hour = int(np.random.choice(hours, p=probs))
        minute = random.randint(0, 59)
        ts = d.replace(hour=hour, minute=minute)
        dp = daypart(hour)
        weather = weather_for(ts)
        traffic = traffic_level(hour, dow)

        # pick customer
        cust = random.choice(customers)
        cust_prefs = set(cust["pref_cuisines"].split("|"))
        tried = set(cust["restaurants_tried"].split("|"))

        # ---- STEP 1: choose the restaurant for this order -----------------
        # A diner picks a restaurant, then eats from its menu.  The restaurant
        # choice is driven by rating CREDIBILITY (shrunk rating, so a new place
        # with 15 reviews cannot dominate), cuisine fit, familiarity (their own
        # history is weighted up) and whether it is open at this hour.
        rest_scores, rest_dist = [], {}
        for rid, r in RESTAURANTS.items():
            if not (r["open_from"] <= hour <= r["open_to"]):
                continue
            d_km = road_km((cust["lat"], cust["lng"]), (r["lat"], r["lng"]))
            rest_dist[rid] = d_km
            s = shrunk_rating(r) / CITY_MEAN_RATING        # quality, credibility-adjusted
            s *= 1.0 + 0.35 * (r["rating_count"] / 4200.0)  # well-known places get more traffic
            if r["cuisine"] in cust_prefs:
                s *= 2.1
            if BY_RESTAURANT_TAGS.get(rid, set()) & cust_prefs:
                s *= 1.15            # the menu itself matches what they like
            s *= 2.6 if rid in tried else 1.0               # repeat behaviour
            s *= 1.6 if (r["is_new"] and rid not in tried and random.random() < 0.35) else 1.0
            if weather == 2 and r["cuisine"] in ("Beverage", "Fast Food", "Late Night"):
                s *= 1.25
            if hour >= 21 and r["cuisine"] in ("Late Night", "Arabian", "Fast Food"):
                s *= 1.4
            # distance decay: diners overwhelmingly order from their own
            # neighbourhood, which is also what keeps delivery times sane
            s *= math.exp(-d_km / 4.0)
            rest_scores.append((rid, max(s, 1e-9)))
        if not rest_scores:
            continue
        rids = [x[0] for x in rest_scores]
        rw = np.array([x[1] for x in rest_scores], dtype=float)
        rid = str(np.random.choice(rids, p=rw / rw.sum()))
        rest = RESTAURANTS[rid]

        # ---- STEP 2: draw items from that restaurant's menu ---------------
        n_lines = 1 + (1 if random.random() < 0.42 else 0) + (1 if random.random() < 0.16 else 0)
        basket, scored = [], []
        for it in BY_RESTAURANT[rid]:
            if cust["veg_only"] and not it["veg"]:
                continue
            s = it["popular_base"]
            s *= 1.9 if it["cuisine"] in cust_prefs else 1.0
            s *= CATEGORY_DAYPART[it["category"]][dp]
            if weather == 2 and it["category"] in ("Beverage", "Fast Food"):
                s *= 1.25
            if hour >= 21 and it["category"] in ("Fast Food", "Arabian", "Dessert"):
                s *= 1.35
            scored.append((it, max(s, 1e-6)))
        picks = random.sample(range(len(scored)), k=min(n_lines, len(scored))) if scored else []
        for pi in picks:
            it = scored[pi][0]
            if it["id"] in [b[0] for b in basket]:
                continue
            qty = 1 if random.random() < 0.82 else 2
            basket.append((it["id"], qty))
        if not basket:
            continue

        order_seq += 1
        order_id = f"O{order_seq:05d}"
        cid = cust["customer_id"]
        cust["orders_placed"] += 1

        total_prep = max(ITEMS[i]["prep_time_min"] for i, _ in basket)
        delay = {"morning": 0.2, "lunch": 2.4, "evening": 1.1, "night": 1.6}[dp]
        prep_time = round(min(38.0, max(4.0, total_prep + delay + np.random.normal(0, 0.9))), 1)

        distance_km = round(float(np.clip(rest_dist[rid], 0.4, 16.0)), 2)
        riders_free = max(0, int(np.random.poisson(2.2 if hour in (19, 20, 21, 13) else 4.0)) - (2 if weather == 2 else 0))
        n_items_total = sum(q for _, q in basket)

        # ---- ground-truth ETA physics (what the ML model has to recover) ----
        # Deliberately NON-linear, the way a real kitchen+rider system behaves:
        #  * the distance term saturates (sqrt component — motorway vs last mile)
        #  * kitchen queueing is CONVEX: a 30-min dish in a busy kitchen slips far
        #    more than a 10-min dish
        #  * rain hurts most exactly during the two peak windows
        travel = (distance_km * 2.45 + 3.0) * (1.0 + 0.19 * (traffic - 1))
        travel *= (1.0 + 0.12 * weather)
        travel *= (1.0 + 0.045 * math.sqrt(distance_km * traffic))     # saturating component
        queue_penalty = 0.35 * max(0.0, total_prep - 20.0) ** 1.35     # convex congestion
        peak_rain = 3.5 if (weather == 2 and hour in (12, 13, 19, 20, 21)) else 0.0
        load_pen = 1.6 * max(0, n_items_total - 3) + 0.55 * max(0, 3 - riders_free)
        eta_true = prep_time + travel + queue_penalty + peak_rain + load_pen + np.random.normal(0, 2.2)
        eta_true = float(np.clip(eta_true, 9.0, 95.0))

        rows.append({
            "order_id": order_id, "timestamp": ts.isoformat(timespec="minutes"),
            "customer_id": cid, "localities": cust["locality"],
            "restaurant_id": rid, "restaurant_name": rest["name"],
            "restaurant_rating": rest["rating"], "restaurant_rating_count": rest["rating_count"],
            "restaurant_cuisine": rest["cuisine"], "restaurant_is_new": int(rest["is_new"]),
            "n_line_items": len(basket), "n_units": n_items_total,
            "basket_value": sum(ITEMS[i]["price"] * q for i, q in basket),
            "distance_km": distance_km, "prep_time_min": prep_time,
            "traffic_level": traffic, "weather": weather, "riders_free": riders_free,
            "hour": hour, "day_of_week": dow, "is_weekend": int(dow >= 5),
            "actual_eta_min": round(eta_true, 1),
            "items": "|".join(f"{i}:{q}" for i, q in basket),
        })
        for i, q in basket:
            lines.append({
                "order_id": order_id, "timestamp": ts.isoformat(timespec="minutes"),
                "customer_id": cid, "restaurant_id": rid, "restaurant_name": rest["name"],
                "item_id": i, "item_name": ITEMS[i]["name"],
                "cuisine": ITEMS[i]["cuisine"], "category": ITEMS[i]["category"],
                "qty": q, "price": ITEMS[i]["price"], "hour": hour,
                "day_of_week": dow, "is_weekend": int(dow >= 5),
                "distance_km": distance_km, "weather": weather,
            })

orders_df = pd.DataFrame(rows).sort_values("timestamp").reset_index(drop=True)
lines_df = pd.DataFrame(lines)
orders_df.to_csv(os.path.join(DATA, "orders.csv"), index=False)
lines_df.to_csv(os.path.join(DATA, "order_lines.csv"), index=False)

# ----------------------------------------------------------------- riders
RIDER_NAMES = ["Arun K", "Divya S", "Karthik R", "Meena P", "Saravanan M", "Priya V",
               "Vignesh T", "Nandini B", "Hari Prasad", "Anitha G", "Suresh N",
               "Kavya L", "Mohan D", "Rajeshwari"]
riders = []
for i, nm in enumerate(RIDER_NAMES):
    riders.append({
        "rider_id": f"R{i+1:02d}", "name": nm,
        "lat": round(11.0168 + np.random.normal(0, 0.028), 5),   # around Coimbatore centre
        "lng": round(76.9558 + np.random.normal(0, 0.028), 5),
        "rating": round(float(np.clip(np.random.normal(4.5, 0.25), 3.6, 5.0)), 2),
        "active_orders": int(np.random.choice([0, 0, 1, 1, 2, 3])),
        "vehicle": random.choice(["bike", "bike", "bike", "scooter", "cycle"]),
    })
with open(os.path.join(DATA, "riders.json"), "w", encoding="utf-8") as f:
    json.dump(riders, f, indent=2)

print(f"orders.csv        {orders_df.shape[0]:>6} orders   (x {orders_df.shape[1]} cols)")
print(f"order_lines.csv   {lines_df.shape[0]:>6} line items")
print(f"customers.csv     {cust_df.shape[0]:>6} customers")
print(f"riders.json       {len(riders):>6} riders")
print(f"date range        {orders_df.timestamp.min()}  ->  {orders_df.timestamp.max()}")
print(f"restaurants       {orders_df.restaurant_id.nunique():>6} with orders  "
      f"(marketplace has {len(RESTAURANTS)})")
_rr = (orders_df.groupby("restaurant_name").size().sort_values(ascending=False))
print("top restaurants   " + ", ".join(f"{n} ({c})" for n, c in _rr.head(5).items()))
print(f"new restaurants   {orders_df[orders_df.restaurant_is_new == 1].restaurant_id.nunique():>6} "
      f"of {sum(1 for r in RESTAURANTS.values() if r['is_new'])} received discovery orders")
print(f"mean actual ETA   {orders_df.actual_eta_min.mean():.1f} min  "
      f"(p10={orders_df.actual_eta_min.quantile(.1):.0f}, p90={orders_df.actual_eta_min.quantile(.9):.0f})")
