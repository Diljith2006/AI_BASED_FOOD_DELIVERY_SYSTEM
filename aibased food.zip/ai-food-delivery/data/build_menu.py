"""
data/build_menu.py — generates data/menu.json for a MULTI-RESTAURANT marketplace
--------------------------------------------------------------------------------
Why a builder instead of a hand-written menu.json: a marketplace has cross-cutting
consistency rules that a human editor breaks silently —

  * every item must belong to a restaurant that exists,
  * an item cannot be rated better than the restaurant it comes from (mostly),
  * a "new" restaurant has FEW ratings, which is exactly why its headline rating
    cannot be trusted — that is what the Bayesian shrinkage in the recommender
    exists for,
  * price_for_two is derived from the actual menu, not typed twice.

The spec below is the single source of truth; menu.json is generated, and
`python data/build_menu.py --check` fails loudly if any rule is violated.

Coimbatore localities are real; the restaurants are invented for the demo.
"""
from __future__ import annotations

import argparse, json, os, sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ai.geo import CITY_CENTRE, road_km   # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "data", "menu.json")

# --------------------------------------------------------------------------
# Localities (shared with the order generator and the app for real distances)
# --------------------------------------------------------------------------
LOCALITIES = {
    "R.S. Puram":       (10.9978, 76.9510),
    "Peelamedu":        (11.0280, 76.9630),
    "Saibaba Colony":   (11.0185, 76.9380),
    "Gandhipuram":      (11.0170, 76.9674),
    "Vadavalli":        (11.0270, 76.8880),
    "Singanallur":      (10.9930, 77.0030),
    "Race Course":      (11.0040, 76.9720),
    "Thudiyalangulam":  (11.0500, 76.9600),
    "Kuniamuthur":      (10.9600, 76.9500),
    "Saravanampatti":   (11.0650, 77.0000),
    "Ganapathy":        (11.0300, 76.9800),
}

# --------------------------------------------------------------------------
# Restaurants
#   rating_count is what makes the rating *credible*: R11/R12/R13 are brand new
#   with high headline ratings but only a handful of reviews, so the shrunk
#   rating used for ranking pulls them back toward the city average.
# --------------------------------------------------------------------------
RESTAURANTS = [
    dict(id="R01", name="Sizzle.AI Kitchen", cuisine="South Indian", locality="Peelamedu",
         rating=4.6, rating_count=1840, price_for_two=280, prep_speed=1.00, open_from=6, open_to=23,
         badge="", tags=["flagship", "tiffin", "gunpowder", "veg friendly"]),
    dict(id="R02", name="Kongu Ruchi Mess", cuisine="Kongunadu", locality="Ganapathy",
         rating=4.5, rating_count=920, price_for_two=340, prep_speed=1.08, open_from=7, open_to=22,
         badge="", tags=["country style", "mutton", "kambu", "warm"],
         signature="Kongunadu Mutton Curry"),
    dict(id="R03", name="Chettinad Spice House", cuisine="Chettinad", locality="R.S. Puram",
         rating=4.7, rating_count=1310, price_for_two=380, prep_speed=1.05, open_from=11, open_to=23,
         badge="Top rated", tags=["spicy", "pepper", "biryani", "non-veg"],
         signature="Chettinad Chicken Biryani"),
    dict(id="R04", name="Punjabi Tadka", cuisine="North Indian", locality="Saibaba Colony",
         rating=4.4, rating_count=2860, price_for_two=420, prep_speed=1.02, open_from=11, open_to=23,
         badge="", tags=["tandoor", "butter", "naan", "family"],
         signature="Butter Chicken"),
    dict(id="R05", name="Wok & Roll", cuisine="Indo-Chinese", locality="Gandhipuram",
         rating=4.2, rating_count=760, price_for_two=300, prep_speed=0.92, open_from=11, open_to=23,
         badge="", tags=["wok", "street", "noodles", "quick"],
         signature="Schezwan Fried Rice"),
    dict(id="R06", name="Arabian Nights Grill", cuisine="Arabian", locality="Kuniamuthur",
         rating=4.6, rating_count=1450, price_for_two=390, prep_speed=1.04, open_from=12, open_to=23,
         badge="", tags=["grill", "charcoal", "shawarma", "late"],
         signature="Chicken Shawarma Roll"),
    dict(id="R07", name="Burger Barn", cuisine="Fast Food", locality="Peelamedu",
         rating=4.0, rating_count=2100, price_for_two=260, prep_speed=0.88, open_from=10, open_to=23,
         badge="", tags=["burger", "fries", "student", "value"],
         signature="Crispy Chicken Burger"),
    dict(id="R08", name="Sweet Karam Coffee", cuisine="Dessert", locality="Saibaba Colony",
         rating=4.8, rating_count=640, price_for_two=180, prep_speed=0.80, open_from=9, open_to=22,
         badge="Top rated", tags=["sweet", "snacks", "festive", "filter coffee"],
         signature="Mysore Pak"),
    dict(id="R09", name="Dosa Junction", cuisine="South Indian", locality="Singanallur",
         rating=4.3, rating_count=3050, price_for_two=200, prep_speed=0.90, open_from=6, open_to=22,
         badge="", tags=["tiffin", "dosa", "budget", "breakfast"],
         signature="Podi Dosa"),
    dict(id="R10", name="The Biryani Company", cuisine="Biryani", locality="Thudiyalangulam",
         rating=4.5, rating_count=4200, price_for_two=400, prep_speed=1.15, open_from=11, open_to=23,
         badge="Most ordered", tags=["biryani", "dum", "family", "weekend"],
         signature="Hyderabadi Chicken Dum Biryani"),
    # ---- recently onboarded: high rating, almost no review volume yet --------
    dict(id="R11", name="Coastal Catch", cuisine="Seafood", locality="Vadavalli",
         rating=4.9, rating_count=38, price_for_two=520, prep_speed=1.20, open_from=12, open_to=22,
         badge="New", new=True, tags=["fish", "prawn", "pepper", "coastal"],
         signature="Meen Kuzhambu"),
    dict(id="R12", name="Bao & Beyond", cuisine="Pan-Asian", locality="Saravanampatti",
         rating=4.8, rating_count=22, price_for_two=560, prep_speed=1.12, open_from=12, open_to=23,
         badge="New", new=True, tags=["ramen", "bao", "korean", "bubble tea"],
         signature="Korean Fried Chicken"),
    dict(id="R13", name="Millets & More", cuisine="Healthy", locality="Vadavalli",
         rating=4.7, rating_count=15, price_for_two=300, prep_speed=0.95, open_from=7, open_to=21,
         badge="New", new=True, tags=["millet", "salad", "diabetic friendly", "light"],
         signature="Millet Dosa"),
    dict(id="R14", name="Namma Night Canteen", cuisine="Late Night", locality="Race Course",
         rating=4.4, rating_count=60, price_for_two=240, prep_speed=0.85, open_from=19, open_to=23,
         badge="New", new=True, tags=["kothu", "omelette", "late", "quick"],
         signature="Chicken Kothu Parotta"),
    dict(id="R15", name="Filter Kaapi Club", cuisine="Beverage", locality="Race Course",
         rating=4.6, rating_count=120, price_for_two=120, prep_speed=0.70, open_from=6, open_to=22,
         badge="", tags=["kaapi", "chai", "rose milk", "snacks"],
         signature="Filter Coffee (Tumbler)"),
]

# --------------------------------------------------------------------------
# Items.  (id, restaurant, name, cuisine, category, price, veg, spice, prep, rating,
#         calories, tags, popularity)
# ratings intentionally sit close to (and never far above) the restaurant rating.
# --------------------------------------------------------------------------
ITEMS = [
    # ---- R01 Sizzle.AI Kitchen ------------------------------------------
    ("M01", "R01", "Ghee Roast Dosa", "South Indian", "Breakfast", 110, True, 1, 9, 4.7, 420, ["crispy", "classic", "tiffin", "chutney"], 0.92),
    ("M02", "R01", "Idli Vada Combo", "South Indian", "Breakfast", 90, True, 1, 6, 4.5, 380, ["light", "steamed", "tiffin", "sambar"], 0.80),
    ("M06", "R01", "Ven Pongal with Coconut Chutney", "South Indian", "Breakfast", 95, True, 1, 8, 4.4, 450, ["comfort", "ghee", "tiffin", "light"], 0.58),
    ("M25", "R01", "Sambar Rice with Ghee", "South Indian", "Main", 140, True, 2, 10, 4.4, 520, ["comfort", "rice", "homely", "one pot"], 0.61),
    ("M26", "R01", "Thayir Sadam (Curd Rice)", "South Indian", "Main", 110, True, 0, 7, 4.3, 430, ["cool", "light", "comfort", "rice"], 0.49),
    ("M27", "R01", "Mushroom Pepper Fry", "South Indian", "Starter", 190, True, 3, 13, 4.5, 340, ["pepper", "spicy", "starter", "dry"], 0.54),

    # ---- R02 Kongu Ruchi Mess -------------------------------------------
    ("M04", "R02", "Kongunadu Mutton Curry", "Kongunadu", "Main", 320, False, 3, 28, 4.6, 690, ["spicy", "gravy", "signature", "roti"], 0.62),
    ("M05", "R02", "Madurai Parotta (2 pc) with Salna", "South Indian", "Main", 120, True, 2, 10, 4.6, 610, ["flaky", "street food", "gravy", "filling"], 0.88),
    ("M28", "R02", "Kongunadu Chicken Kuzhambu", "Kongunadu", "Main", 290, False, 3, 25, 4.6, 640, ["spicy", "gravy", "country style", "rice"], 0.71),
    ("M29", "R02", "Kambu Koozh (Pearl Millet)", "Kongunadu", "Breakfast", 80, True, 1, 6, 4.2, 320, ["millet", "healthy", "cooling", "traditional"], 0.38),
    ("M30", "R02", "Arisi Paruppu Sadam", "Kongunadu", "Main", 130, True, 2, 12, 4.4, 560, ["one pot", "comfort", "rice", "homely"], 0.52),
    ("M31", "R02", "Mutton Kola Urundai (4 pc)", "Kongunadu", "Starter", 240, False, 3, 16, 4.7, 480, ["spicy", "fried", "starter", "mutton"], 0.59),

    # ---- R03 Chettinad Spice House --------------------------------------
    ("M03", "R03", "Chettinad Chicken Biryani", "Chettinad", "Main", 260, False, 3, 22, 4.8, 780, ["spicy", "biryani", "signature", "aromatic"], 0.97),
    ("M14", "R03", "Chicken 65", "Chettinad", "Starter", 230, False, 3, 14, 4.8, 520, ["spicy", "fried", "starter", "crispy"], 0.83),
    ("M32", "R03", "Chettinad Pepper Chicken", "Chettinad", "Main", 280, False, 3, 20, 4.7, 610, ["pepper", "spicy", "dry", "signature"], 0.74),
    ("M33", "R03", "Chettinad Mushroom Masala", "Chettinad", "Main", 210, True, 3, 17, 4.5, 420, ["spicy", "mushroom", "gravy", "veg"], 0.51),
    ("M34", "R03", "Kothu Parotta (Chicken)", "Chettinad", "Fast Food", 200, False, 2, 13, 4.6, 680, ["street food", "minced", "filling", "quick"], 0.78),
    ("M35", "R03", "Pallipalayam Chicken Fry", "Chettinad", "Starter", 260, False, 3, 18, 4.6, 560, ["spicy", "dry", "starter", "coconut"], 0.55),

    # ---- R04 Punjabi Tadka ----------------------------------------------
    ("M09", "R04", "Butter Chicken", "North Indian", "Main", 290, False, 2, 20, 4.7, 720, ["creamy", "gravy", "roti", "mild"], 0.90),
    ("M10", "R04", "Paneer Butter Masala", "North Indian", "Main", 250, True, 2, 18, 4.6, 640, ["creamy", "gravy", "roti", "rich"], 0.86),
    ("M11", "R04", "Dal Tadka with Jeera Rice", "North Indian", "Main", 210, True, 1, 15, 4.3, 540, ["comfort", "rice", "healthy", "mild"], 0.64),
    ("M12", "R04", "Tandoori Roti (2 pc)", "North Indian", "Bread", 60, True, 0, 5, 4.2, 240, ["bread", "tandoor", "side"], 0.55),
    ("M13", "R04", "Garlic Naan", "North Indian", "Bread", 70, True, 0, 6, 4.5, 290, ["bread", "tandoor", "buttery", "side"], 0.70),
    ("M36", "R04", "Amritsari Chole Kulche", "North Indian", "Main", 180, True, 2, 14, 4.5, 580, ["chickpea", "spicy", "street food", "filling"], 0.57),
    ("M37", "R04", "Chicken Tandoori (Half)", "North Indian", "Starter", 330, False, 2, 24, 4.7, 660, ["tandoor", "smoky", "starter", "protein"], 0.68),
    ("M38", "R04", "Punjabi Lassi (Sweet)", "North Indian", "Beverage", 90, True, 0, 4, 4.5, 260, ["cold", "curd", "sweet", "cooling"], 0.47),

    # ---- R05 Wok & Roll --------------------------------------------------
    ("M15", "R05", "Gobi Manchurian", "Indo-Chinese", "Starter", 180, True, 2, 12, 4.4, 480, ["indo-chinese", "fried", "starter", "tangy"], 0.72),
    ("M16", "R05", "Veg Hakka Noodles", "Indo-Chinese", "Main", 190, True, 1, 11, 4.3, 560, ["indo-chinese", "noodles", "quick", "mild"], 0.68),
    ("M17", "R05", "Schezwan Fried Rice", "Indo-Chinese", "Main", 200, True, 2, 12, 4.5, 590, ["indo-chinese", "rice", "spicy", "quick"], 0.76),
    ("M39", "R05", "Chilli Chicken (Dry)", "Indo-Chinese", "Starter", 240, False, 3, 14, 4.5, 540, ["spicy", "fried", "starter", "indo-chinese"], 0.70),
    ("M40", "R05", "Chicken Manchow Soup", "Indo-Chinese", "Starter", 150, False, 2, 9, 4.2, 280, ["soup", "hot", "spicy", "quick"], 0.44),
    ("M41", "R05", "Veg Momos (Steamed, 6 pc)", "Indo-Chinese", "Starter", 160, True, 2, 10, 4.4, 320, ["steamed", "momo", "starter", "chutney"], 0.63),
    ("M42", "R05", "Crispy Corn", "Indo-Chinese", "Starter", 170, True, 2, 9, 4.3, 380, ["crispy", "starter", "veg", "quick"], 0.50),

    # ---- R06 Arabian Nights Grill ----------------------------------------
    ("M18", "R06", "Chicken Shawarma Roll", "Arabian", "Fast Food", 160, False, 2, 8, 4.6, 500, ["wrap", "quick", "late night", "grilled"], 0.89),
    ("M19", "R06", "Al Faham Grilled Chicken (Half)", "Arabian", "Main", 340, False, 2, 25, 4.7, 730, ["grilled", "smoky", "protein", "late night"], 0.66),
    ("M20", "R06", "Kuboos with Hummus", "Arabian", "Starter", 140, True, 1, 7, 4.3, 410, ["dip", "bread", "light", "side"], 0.48),
    ("M43", "R06", "Chicken Mandi (Half)", "Arabian", "Main", 380, False, 2, 30, 4.8, 820, ["mandi", "smoky", "rice", "family"], 0.72),
    ("M44", "R06", "Falafel Plate", "Arabian", "Starter", 180, True, 2, 9, 4.2, 430, ["fried", "chickpea", "veg", "dip"], 0.41),
    ("M45", "R06", "Grilled Chicken Wings (6 pc)", "Arabian", "Starter", 220, False, 2, 13, 4.5, 470, ["grilled", "starter", "spicy", "late night"], 0.58),

    # ---- R07 Burger Barn -------------------------------------------------
    ("M21", "R07", "Veg Burger with Fries", "Fast Food", "Fast Food", 170, True, 1, 9, 4.1, 620, ["burger", "fried", "quick", "combo"], 0.61),
    ("M46", "R07", "Crispy Chicken Burger", "Fast Food", "Fast Food", 190, False, 2, 10, 4.2, 680, ["burger", "fried", "quick", "crispy"], 0.72),
    ("M47", "R07", "Peri Peri Fries", "Fast Food", "Starter", 120, True, 2, 7, 4.3, 380, ["fried", "spicy", "side", "quick"], 0.66),
    ("M48", "R07", "Chicken Nuggets (6 pc)", "Fast Food", "Starter", 160, False, 1, 8, 4.0, 420, ["fried", "starter", "kids", "dip"], 0.52),
    ("M49", "R07", "Chicken Popcorn", "Fast Food", "Starter", 170, False, 2, 9, 4.1, 450, ["fried", "crunchy", "starter", "share"], 0.55),
    ("M50", "R07", "Cold Coffee", "Beverage", "Beverage", 110, True, 0, 4, 4.2, 240, ["cold", "coffee", "creamy", "quick"], 0.48),

    # ---- R08 Sweet Karam Coffee -----------------------------------------
    ("M22", "R08", "Gulab Jamun (2 pc)", "Dessert", "Dessert", 90, True, 0, 4, 4.7, 350, ["sweet", "warm", "dessert", "classic"], 0.57),
    ("M23", "R08", "Payasam (Semiya)", "Dessert", "Dessert", 100, True, 0, 5, 4.5, 300, ["sweet", "milky", "festive", "dessert"], 0.42),
    ("M51", "R08", "Mysore Pak (2 pc)", "Dessert", "Dessert", 80, True, 0, 3, 4.8, 380, ["ghee", "sweet", "signature", "traditional"], 0.64),
    ("M52", "R08", "Basundi", "Dessert", "Dessert", 120, True, 0, 4, 4.6, 330, ["milky", "sweet", "chilled", "festive"], 0.40),
    ("M53", "R08", "Brownie with Ice Cream", "Dessert", "Dessert", 180, True, 0, 5, 4.5, 480, ["chocolate", "warm", "dessert", "indulgent"], 0.58),
    ("M54", "R08", "Kunafa (Arabian Sweet)", "Dessert", "Dessert", 200, True, 0, 7, 4.6, 460, ["crispy", "sweet", "arabian", "dessert"], 0.44),

    # ---- R09 Dosa Junction ----------------------------------------------
    ("M55", "R09", "Podi Dosa", "South Indian", "Breakfast", 100, True, 2, 8, 4.5, 400, ["crispy", "spicy", "tiffin", "gunpowder"], 0.70),
    ("M56", "R09", "Onion Uthappam", "South Indian", "Breakfast", 110, True, 2, 10, 4.3, 430, ["thick", "tiffin", "onion", "chutney"], 0.58),
    ("M57", "R09", "Kal Dosa with Kurma", "South Indian", "Breakfast", 90, True, 2, 7, 4.4, 450, ["soft", "gravy", "budget", "tiffin"], 0.62),
    ("M58", "R09", "Rava Dosa", "South Indian", "Breakfast", 120, True, 1, 9, 4.4, 380, ["crispy", "lacy", "tiffin", "classic"], 0.60),
    ("M59", "R09", "Set Dosa (3 pc)", "South Indian", "Breakfast", 100, True, 1, 8, 4.2, 410, ["soft", "spongy", "tiffin", "budget"], 0.47),
    ("M60", "R09", "Poori Masala", "South Indian", "Breakfast", 100, True, 1, 8, 4.3, 520, ["fried", "potato", "tiffin", "filling"], 0.51),

    # ---- R10 The Biryani Company ----------------------------------------
    ("M61", "R10", "Hyderabadi Chicken Dum Biryani", "Biryani", "Main", 300, False, 3, 24, 4.7, 800, ["biryani", "dum", "spicy", "signature"], 0.94),
    ("M62", "R10", "Mutton Dum Biryani", "Biryani", "Main", 380, False, 3, 28, 4.6, 850, ["biryani", "dum", "rich", "weekend"], 0.74),
    ("M63", "R10", "Veg Dum Biryani", "Biryani", "Main", 220, True, 2, 20, 4.3, 620, ["biryani", "veg", "aromatic", "filling"], 0.60),
    ("M64", "R10", "Prawn Biryani", "Biryani", "Main", 340, False, 3, 24, 4.5, 720, ["biryani", "seafood", "spicy", "premium"], 0.45),
    ("M65", "R10", "Egg Biryani", "Biryani", "Main", 200, False, 2, 18, 4.2, 660, ["biryani", "egg", "budget", "filling"], 0.53),
    ("M66", "R10", "Chicken 65 Biryani", "Biryani", "Main", 320, False, 3, 25, 4.6, 860, ["biryani", "spicy", "fried", "combo"], 0.69),

    # ---- R11 Coastal Catch (NEW) ----------------------------------------
    ("M67", "R11", "Meen Kuzhambu (Fish Curry)", "Seafood", "Main", 320, False, 3, 22, 4.9, 520, ["fish", "tamarind", "spicy", "signature"], 0.55),
    ("M68", "R11", "Vanjaram Fish Fry", "Seafood", "Starter", 280, False, 3, 14, 4.8, 460, ["fish", "fried", "spicy", "coastal"], 0.48),
    ("M69", "R11", "Prawn Masala", "Seafood", "Main", 340, False, 3, 18, 4.9, 480, ["prawn", "spicy", "gravy", "premium"], 0.52),
    ("M70", "R11", "Squid Fry", "Seafood", "Starter", 300, False, 3, 15, 4.7, 420, ["squid", "fried", "crispy", "coastal"], 0.38),
    ("M71", "R11", "Crab Pepper Masala", "Seafood", "Main", 380, False, 3, 20, 4.9, 500, ["crab", "pepper", "spicy", "premium"], 0.40),

    # ---- R12 Bao & Beyond (NEW) -----------------------------------------
    ("M72", "R12", "Chicken Bao (2 pc)", "Pan-Asian", "Starter", 190, False, 2, 11, 4.7, 380, ["bao", "steamed", "starter", "soft"], 0.46),
    ("M73", "R12", "Chicken Ramen", "Pan-Asian", "Main", 290, False, 2, 16, 4.8, 620, ["ramen", "noodles", "soup", "comfort"], 0.58),
    ("M74", "R12", "Veg Sushi Roll (8 pc)", "Pan-Asian", "Main", 260, True, 1, 14, 4.6, 400, ["sushi", "rice", "light", "premium"], 0.42),
    ("M75", "R12", "Korean Fried Chicken", "Pan-Asian", "Starter", 320, False, 3, 15, 4.9, 620, ["korean", "fried", "spicy", "signature"], 0.62),
    ("M76", "R12", "Bubble Tea", "Beverage", "Beverage", 150, True, 0, 5, 4.5, 260, ["cold", "boba", "sweet", "trending"], 0.44),

    # ---- R13 Millets & More (NEW) ---------------------------------------
    ("M77", "R13", "Millet Dosa with Chutney", "Healthy", "Breakfast", 130, True, 1, 9, 4.7, 340, ["millet", "healthy", "crispy", "light"], 0.45),
    ("M78", "R13", "Barnyard Millet Upma", "Healthy", "Breakfast", 110, True, 1, 7, 4.6, 300, ["millet", "light", "breakfast", "healthy"], 0.36),
    ("M79", "R13", "Multigrain Salad Bowl", "Healthy", "Main", 190, True, 1, 6, 4.7, 280, ["salad", "fresh", "protein", "light"], 0.41),
    ("M80", "R13", "Millet Pongal", "Healthy", "Breakfast", 120, True, 1, 8, 4.5, 360, ["millet", "comfort", "light", "healthy"], 0.34),
    ("M24", "R13", "Tender Coconut Cooler", "Beverage", "Beverage", 80, True, 0, 4, 4.4, 120, ["cold", "refreshing", "summer", "healthy"], 0.51),

    # ---- R14 Namma Night Canteen (NEW) ----------------------------------
    ("M81", "R14", "Chicken Kothu Parotta", "Late Night", "Fast Food", 210, False, 2, 10, 4.5, 700, ["kothu", "street food", "late night", "filling"], 0.52),
    ("M82", "R14", "Egg Dosa", "Late Night", "Fast Food", 110, False, 2, 7, 4.3, 420, ["egg", "tiffin", "quick", "late night"], 0.40),
    ("M83", "R14", "Cheese Omelette", "Late Night", "Fast Food", 120, False, 1, 6, 4.2, 380, ["egg", "cheese", "quick", "late night"], 0.35),
    ("M84", "R14", "Chicken Fried Rice", "Late Night", "Main", 200, False, 2, 11, 4.3, 640, ["rice", "quick", "late night", "spicy"], 0.44),
    ("M85", "R14", "Bread Omelette", "Late Night", "Fast Food", 90, False, 1, 6, 4.1, 340, ["egg", "budget", "quick", "late night"], 0.33),

    # ---- R15 Filter Kaapi Club ------------------------------------------
    ("M07", "R15", "Filter Coffee (Tumbler)", "Beverage", "Beverage", 45, True, 0, 3, 4.9, 90, ["hot", "classic", "caffeine", "strong"], 0.85),
    ("M08", "R15", "Masala Chai", "Beverage", "Beverage", 40, True, 0, 3, 4.6, 110, ["hot", "ginger", "comfort"], 0.74),
    ("M86", "R15", "Rose Milk", "Beverage", "Beverage", 70, True, 0, 4, 4.7, 180, ["cold", "sweet", "classic", "rose"], 0.55),
    ("M87", "R15", "Sukku Malli Coffee", "Beverage", "Beverage", 50, True, 0, 4, 4.6, 100, ["herbal", "hot", "digestive", "traditional"], 0.38),
    ("M88", "R15", "Badam Milk", "Beverage", "Beverage", 80, True, 0, 4, 4.5, 220, ["almond", "hot", "sweet", "healthy"], 0.42),
    ("M89", "R15", "Medu Vada (2 pc)", "South Indian", "Starter", 60, True, 1, 6, 4.4, 260, ["crispy", "snack", "tiffin", "chutney"], 0.49),
]


def build() -> dict:
    by_rest = {r["id"]: r for r in RESTAURANTS}
    items = []
    for (iid, rid, name, cuisine, cat, price, veg, spice, prep, rating, cal, tags, pop) in ITEMS:
        r = by_rest[rid]
        items.append({
            "id": iid, "restaurant_id": rid, "restaurant_name": r["name"],
            "name": name, "cuisine": cuisine, "category": cat, "price": price,
            "veg": veg, "spice": spice, "prep_time_min": prep, "rating": rating,
            "calories": cal, "tags": tags, "popular_base": pop,
        })

    restaurants = []
    for r in RESTAURANTS:
        mine = [i for i in items if i["restaurant_id"] == r["id"]]
        if not mine:
            raise ValueError(f"{r['id']} {r['name']} has no items")
        lat, lng = LOCALITIES[r["locality"]]
        rest_pt = (lat + 0.004, lng - 0.003)
        dist_hint = round(road_km(CITY_CENTRE, rest_pt), 1)
        # price_for_two is derived, not typed: two mains + two drinks/breads
        mains = sorted([i["price"] for i in mine if i["category"] in ("Main", "Biryani")] or [0])
        restaurants.append({
            "id": r["id"], "name": r["name"], "cuisine": r["cuisine"], "locality": r["locality"],
            "lat": round(lat + 0.004, 5), "lng": round(lng - 0.003, 5),
            "rating": r["rating"], "rating_count": r["rating_count"],
            "is_new": bool(r.get("new", False)), "badge": r.get("badge", ""),
            "cost_for_two": r["price_for_two"],
            "suggested_price_for_two": int(round(sum(mains[:2]) * 1.35 / 10) * 10),
            "prep_speed": r["prep_speed"], "open_from": r["open_from"], "open_to": r["open_to"],
            "distance_hint_km": dist_hint,
            "tags": r["tags"], "signature_dish": r.get("signature", ""),
            "item_count": len(mine),
            "avg_item_price": round(sum(i["price"] for i in mine) / len(mine), 1),
            "menu_rating": round(sum(i["rating"] for i in mine) / len(mine), 2),
        })

    return {
        "marketplace": {
            "name": "Sizzle.AI",
            "city": "Coimbatore, Tamil Nadu",
            "currency": "INR",
            "restaurants": len(restaurants),
            "items": len(items),
            "new_restaurants": [r["id"] for r in restaurants if r["is_new"]],
            "kitchen_capacity_orders_per_hour": 60,
            "riders_on_shift": 14,
        },
        "restaurants": restaurants,
        "items": items,
    }


def check(menu: dict) -> list[str]:
    """Consistency rules a marketplace silently violates if nothing checks."""
    errs = []
    rids = {r["id"] for r in menu["restaurants"]}
    ids, names = set(), set()
    global_items = len(menu["items"])
    for i in menu["items"]:
        if i["restaurant_id"] not in rids:
            errs.append(f"{i['id']} points at missing restaurant {i['restaurant_id']}")
        if i["id"] in ids:
            errs.append(f"duplicate item id {i['id']}")
        if i["name"].lower() in names:
            errs.append(f"duplicate item name {i['name']}")
        ids.add(i["id"]); names.add(i["name"].lower())
        # an item must not be rated far above its restaurant — that mismatch is
        # what makes marketplace ratings look fake
        rest = next(r for r in menu["restaurants"] if r["id"] == i["restaurant_id"])
        if i["rating"] - rest["rating"] > 0.35:
            errs.append(f"{i['id']} rating {i['rating']} exceeds {rest['name']} {rest['rating']} by >0.35")
        if i["price"] <= 0 or i["prep_time_min"] <= 0:
            errs.append(f"{i['id']} has non-positive price/prep")
    for r in menu["restaurants"]:
        if not r["item_count"]:
            errs.append(f"{r['name']} has no items")
        if r["rating_count"] < 0:
            errs.append(f"{r['name']} has a negative review count")
    if global_items != len(menu["items"]):
        errs.append("item count mismatch")
    return errs


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true", help="validate the existing menu.json instead of rebuilding")
    args = ap.parse_args()

    if args.check:
        menu = json.load(open(OUT, encoding="utf-8"))
    else:
        menu = build()
        json.dump(menu, open(OUT, "w", encoding="utf-8"), indent=1, ensure_ascii=False)

    errs = check(menu)
    m = menu["marketplace"]
    print(f"{m['restaurants']} restaurants  |  {m['items']} items  |  "
          f"{len(m['new_restaurants'])} new  |  city {m['city']}")
    for r in sorted(menu["restaurants"], key=lambda x: -x["rating"]):
        flag = " NEW" if r["is_new"] else "    "
        print(f"  {r['id']} {r['name']:24} {r['rating']:.1f}★ ({r['rating_count']:>4}) "
              f"{r['item_count']:>2} items  ₹{r['cost_for_two']:>3} for two  {r['locality']}{flag}")
    if errs:
        print("\nCONSISTENCY ERRORS:")
        for e in errs:
            print("  -", e)
        sys.exit(1)
    print("\nconsistency check passed")
