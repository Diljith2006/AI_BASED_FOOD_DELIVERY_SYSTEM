"""
tools/process_images.py — normalise dish photography for the menu cards.
------------------------------------------------------------------------
Turns whatever the image generator returns (large, various aspect ratios, and
sometimes with black letterbox bars) into a uniform 640×~350 JPEG:

  1. trim near-black letterbox rows/columns left by the generator,
  2. resize to 640 px wide,
  3. crop to a 3:2 card window biased slightly above centre (plated food sits high),
  4. re-encode as progressive optimised JPEG (~45 KB) so 24+ photos stay cheap.

Run after adding new photos:   python tools/process_images.py
Idempotent — safe to run on already-processed files.
"""
from __future__ import annotations

import glob, os, sys

from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
IMG_DIR = os.path.join(ROOT, "static", "img")
TARGET_W, CROP_H, QUALITY = 640, 430, 82
BLACK = 12          # a row/column averaging below this is treated as a letterbox bar


def trim_letterbox(im: Image.Image) -> Image.Image:
    g = im.convert("L")
    w, h = im.size
    px = g.load()

    def row_mean(y):
        return sum(px[x, y] for x in range(0, w, 4)) / (w // 4 + 1)

    def col_mean(x):
        return sum(px[x, y] for y in range(0, h, 4)) / (h // 4 + 1)

    top = 0
    while top < h and row_mean(top) < BLACK:
        top += 1
    bot = h - 1
    while bot > top and row_mean(bot) < BLACK:
        bot -= 1
    left = 0
    while left < w and col_mean(left) < BLACK:
        left += 1
    right = w - 1
    while right > left and col_mean(right) < BLACK:
        right -= 1
    if (top, bot, left, right) != (0, h - 1, 0, w - 1):
        return im.crop((left, top, right + 1, bot + 1))
    return im


def process(path: str, verbose: bool = True) -> tuple[int, int]:
    before = os.path.getsize(path)
    im = trim_letterbox(Image.open(path).convert("RGB"))
    w, h = im.size
    if w != TARGET_W:
        im = im.resize((TARGET_W, max(1, int(h * TARGET_W / w))), Image.LANCZOS)
    if im.height > CROP_H:                       # crop, biased above centre
        top = int(max(0, (im.height - CROP_H) * 0.35))
        im = im.crop((0, top, TARGET_W, top + CROP_H))
    im.save(path, "JPEG", quality=QUALITY, optimize=True, progressive=True)
    after = os.path.getsize(path)
    if verbose:
        print(f"  {os.path.basename(path):10} {w}x{h} -> {im.size}  {before//1024}KB -> {after//1024}KB")
    return before, after


if __name__ == "__main__":
    files = sorted(glob.glob(os.path.join(IMG_DIR, "*.jpg")))
    if not files:
        print("no photos found"); sys.exit(0)
    tb = ta = 0
    for f in files:
        b, a = process(f)
        tb += b; ta += a
    print(f"\n{len(files)} photos  {tb//1024}KB -> {ta//1024}KB")
